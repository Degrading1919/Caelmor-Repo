# Neil Richards portfolio research archive

- [Architecture and environment sheets](architecture.md) covers the aboveground portfolio, individual sheet observations, production notes and separate studio credits.
- [Archaeology, biomes and production](production.md) includes the 46-entry environment album inventory, related album title inventories, sheet-level evidence and the early-to-shipped Senntisten comparison.
- [Final synthesis](synthesis.md) draws on both completed crawls and distinguishes documented decisions, visual observations and proposals for Caelmor.

The catalog is comprehensive within the recorded ArtStation album scope. Visual analysis samples individual sheets and gives the coverage for each case. The RuneScape Wiki category was unavailable to the research reader, so direct portfolios and studio credits carry the attribution. This archive contains text and source links.

