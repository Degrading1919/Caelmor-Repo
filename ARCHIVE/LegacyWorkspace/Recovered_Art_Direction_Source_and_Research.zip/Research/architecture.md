# Neil Richards (Zephusees): Aboveground RuneScape Environment Portfolio Notes

**Research status:** catalog review and selected-image analysis of aboveground built-environment candidates found in Neil Richards’ RuneScape Environments album: selected individual sheets from Menaphos, Fort Forinthry, Iaia, Fort Skilling Update, Guthix Hall, both Elf Buildings entries, Tower of Voices, Pioneer House, Bandos Tower, Eastern Island Buildings, Goshima, Lost Grove, Creepy Houses, Haunted Houses and Ship builder were visually inspected. Non-architectural/other-artist entries and remaining sheets are tracked separately. All visual claims cite the individual sheet.

**Coverage boundary:** Aboveground built environments, settlement/city design, building sets and supporting production material. Kharid-Et, archaeological/subterranean locations, prehistory and production catalog are assigned to the parallel researcher and are excluded here. Some projects can straddle those boundaries; I list but do not analyze those categories.

**Review coverage and limitation:** Read project descriptions and visible artwork captions for the 15 artist projects in the table marked image-reviewed. Obtained and examined full-resolution images directly from ArtStation public CDN, using several sheets per project where available. Caption order below is page display order, not an official sheet number. Goshima’s page text fetch failed initially, but its CDN sheets were obtained from the environment-gallery DOM and visually inspected. The full album was reconciled with the production researcher’s 46-entry title inventory; non-architectural props, below-ground and broader production-catalog pieces are explicitly listed as out of scope or text-only leads. Selected sheets rather than every image in large galleries were reviewed; per-project sheet coverage is stated in the inventory and sections below.

## Artist and portfolio framing

Neil Richards' [ArtStation résumé](https://zephusees.artstation.com/resume) states he was Lead Concept Artist at Jagex from June 2004 to December 2023 and describes his RuneScape 3 role as “Lead concept and production artist.” His [portfolio index](https://zephusees.artstation.com/) includes numerous RuneScape Environment projects, including Menaphos, Fort Forinthry, Iaia Buildings, Elf City and multiple archaeology projects. This establishes broad role/context, not authorship of every image or final implementation.

## Menaphos — city-scale concept-to-production sequence

Primary source: [Menaphos project](https://zephusees.artstation.com/projects/BWdWl).

**Artist statement:** Richards says the project collection shows work for a large update, from initial map designs, blockouts and mood shots through paintovers, building designs and props. He explicitly cautions that many designs are his own and differ from the final city layout because designs change and are reworked during production. This is a vital attribution caveat: treat these sheets as process / option history, not a definitive record of the shipped city.

**Paraphrased gallery inventory in page order.** Related captions are grouped.

1. Paintover on a three-dimensional base
2. Early design study
3. Second early design study
4. District palettes paired with NPC designs credited to David Barker
5. Principal pyramid study
6. Close detail study
7. Reapplication of the main gate models
8. Facade study whose ornament makes kit decomposition difficult
9. Two prop studies
10. Paintover work
11. Entrance palette study
12. Palette at the aqueduct above the lower district
13. Market color exploration
14. Perimeter fortification color study
15. Riverside color exploration
16. Merchant district palette study
17. Three surface studies
18. Alternative way into the dungeon
19. Old and new foliage used together
20. Two dungeon-kit studies
21. First spatial mockup in 3D
22. Proposed map

**Visible evidence:** The art-direction, city-buildings, city-temples and RuneFest paintover sheets are visually reviewed below. Other labelled Menaphos images remain caption-only.

**Production inferences (tentative):** The caption sequence suggests a broad pipeline in which urban-scale organization and blockout coexist with district identity, landmark studies, modular/kit concerns, props, materials/textures and paintovers. Caption 8 directly signals that decorative detail was recognized as excessive for kit breakup. The paired gate-model reuse caption suggests explicit reuse was part of the design conversation. These are process inferences from labels, not image observations or universal claims about Jagex workflow.

**Unknowns:** Which images are contemporaneous vs retrospective; exact shipped-vs-proposed asset correspondence; final city layout and in-game kit constraints; dimensions, counts, budgets, and responsibilities beyond explicit caption credits.

## Fort Forinthry — bounded update and production handoff

Primary source: [Fort Forinthry project](https://zephusees.artstation.com/projects/PXaxR1).

**Artist statement and credits:** Richards calls it production work for “a smaller update for a new Fort” and says his main contribution was model sheets and paintovers to work from. He credits initial Fort designs to [Barkbrush](https://www.artstation.com/barkbrush). For models, he credits [Anouk De Bruyne](https://www.artstation.com/anoukdebruyne) for Fort and walls, layout and project management; [Littlebigbang](https://www.artstation.com/littlebigbang) for the Command building; [Harrys8732](https://www.artstation.com/harrys8732) for the Chapel; and [Rickyct](https://www.artstation.com/rickyct) for Workshop area and walls. Copyright Jagex.

**Paraphrased gallery inventory in page order.**

1. Central stronghold
2. Towers integrated with fortifications
3. In-game lighting and palette exploration
4. Workshop exterior
5. Sheltered interior view
6. Stone-processing station exploration
7. Chapel exterior
8. Window variants for different deities
9. Chapel inside view
10. Reference paintover for the stronghold interior
11. Entry assembly
12. Reusable hearth pieces
13. Modular fortification sections
14. Lifting equipment for masonry
15. Reusable wall-defense parts

**Visible evidence:** Captions identify a building/feature set; actual keep, tower, wall, stone-cutting, chapel-window and interior sheets are visually reviewed below. Other sheets such as the workshop and crane remain caption-only.

**Production inferences (tentative):** The artist's role appears to be downstream of initial design and focused on actionable reference sheets / paintovers, coordinated with separate 3D model and layout owners. The caption set points to a compact fort composed of distinguishable functional buildings (keep, workshop, chapel, command building) and reusable fortification/support assets. The presence of interior, lighting, color, stone processing and defense studies suggests attention to use/readability and activity as well as exterior silhouette. Only the role split and labels are explicit; implementation details remain unknown.

**Unknowns:** Whether sheet order indicates chronology; which concepts shipped; degree of modularity or shared material/texture use; layout iterations; game camera/readability constraints; individual asset performance budgets.

## Iaia Buildings — nonhuman architecture and environmental integration

Primary source: [Iaia Buildings project](https://zephusees.artstation.com/projects/wJyqGO).

**Artist statement:** Richards describes it as work contributing to the Dragon Rider homeworld. He explains a functional premise: fish farming, with prior generations gliding/diving from perches to fish. He says egg-shaped pools and Pamukkale (a place he visited) inspired the look. He frames the design question as imagining architecture for another species. He credits [Anouk De Bruyne](https://www.artstation.com/anoukdebruyne) with crafting the work; responsibility for specific final assets should not be reassigned solely from this page.

**Paraphrased gallery inventory.** First sketches, a palette adjustment against the sky, root-based arrangement and abandoned cliff siting, detailed three-dimensional kit callouts, a follow-up prop sheet, and a scene sky study.

**Visible evidence:** Individual original/recolor, top-view, building-kit, pillar and skybox sheets were later obtained and visually reviewed below; captions establish recoloring for lighting/sky balance and roots integration.

**Production inferences (tentative):** The design reasoning begins from species behavior and food gathering, then carries into architecture, site integration, prop callouts and atmospheric context. The artist's mention of multiple color and siting ideas demonstrates exploration and adaptation rather than one fixed image. The image set appears to connect building identity to world setting rather than treating architecture as an isolated facade. These are inferences from the artist's written description and captions.

**Unknowns:** Exact final appearance, which options survived, how fishing/gliding functioned in play, who made each prop/model, and the relationship between painted concepts and final assembled scene.

## Portfolio inventory and boundary audit

The artist’s [RuneScape Environments portfolio](https://zephusees.artstation.com/) was reconciled against the 46-title album inventory collected by the parallel production researcher. The matrix below covers all entries in that inventory which the accessible page text or gallery image makes relevant to aboveground architecture, city-scale environment, built settlement, landmark, or building kit. For each project, it records whether only page text or individual image sheets were reviewed. Of these, 15 Richards portfolio galleries have direct visual review in this archive. Selected sheets—not every image from the largest galleries—are enumerated in each review section.

Additional catalogue entries were inspected at text/index level and placed outside this task boundary:

- **Necromancy Buildings and production art**, **Invention Work**, **RuneScape Archaeology Kits**, **Kharid-Et and Digsite**, **Everlight**, **Infernal Source**, **Warforge + Stormguard**, **Dungeon kits**, **Senntisten**, **Elder God Wars**, **Crypt of Wen** and other dungeon/crypt projects: production and/or below-ground focus assigned to the parallel researcher. No architectural analysis is duplicated here.
- **Deep Sea Fishing Update!**: Richards’ page credits the props to Alan O’Brien; not Richards-authored architecture.
- **Iaia Water Plants**, **Fantasy Plant life**, **Ground cover plants**, **Desert Props**, **Original Elf City Clan Logos**, **Props**, **Props 2**, **Caravan/Cart kits** and **Modular boat kits**: adjacent flora, prop, graphic or transport-kit subjects rather than full architectural environments. Caravan/cart and boat kits may be useful for a separate production-kit study but are outside current architectural focus.
- **Fantasy Landscapes**, **Fantasy Landscape**, **Palette Tests**, **Kena Architecture**, personal art, character work, RuneScape weapons and character albums: not identified as aboveground RuneScape architecture within the requested scope.
- **Jagex Environment Art — Menaphos** and **Anouk Debruyne — Fort Forinthry**: separate artists’/studio pages used as narrow collaboration/production cross-checks, not attributed to Richards. Their descriptions are reviewed; their images are not part of Richards’ portfolio image coverage.

The separate artist-index entries **Haunted Houses** and **Creepy Houses** were included in image review because they are built-form design sheets; only Creepy Houses carries an explicit Copyright Jagex statement on its page, while Haunted Houses is included in Richards’ RuneScape Environments portfolio without a visible page credit statement.
## Sources

- [Neil Richards portfolio](https://zephusees.artstation.com/)
- [Neil Richards résumé](https://zephusees.artstation.com/resume)
- [Menaphos](https://zephusees.artstation.com/projects/BWdWl)
- [Fort Forinthry](https://zephusees.artstation.com/projects/PXaxR1)
- [Iaia Buildings](https://zephusees.artstation.com/projects/wJyqGO)
- [Kharid-Et and Digsite - RuneScape](https://zephusees.artstation.com/projects/JlxknR) — listed for coverage boundary only; assigned to parallel researcher, not analyzed.

## Cross-checks added: studio Menaphos record and Fort progression/layout record

These sources were identified by the research lead and checked for captions/descriptions. They improve attribution and systems context; their sheets have also **not** been visually inspected in this session.

### Jagex: The Golden City of Menaphos — Pre Production

Primary source: [Jagex Games Studio, The Golden City Of Menaphos - Pre Production](https://jagex.artstation.com/projects/qGkxa).

**Artist/studio statement:** Jagex describes a large collaborative effort for the 2017 Menaphos update. Named art directors are Martin Severn and Matthew Newstead; art leads Alec Vine, Paul Brown, Matthew Newstead and John McCambridge; concept artists David Barker, Neil Richards and Yann Blomquist. Captions make coauthorship more precise than either crediting every page image to one artist or treating Richards' individual page as the whole project.

**Relevant built-environment captions:** Pyramid and upper levels (David Barker); early Pyramid ideation (David Barker + Neil Richards); city-layout early ideation (David Barker + Neil Richards, and a separate Neil Richards entry); Pyramid early ideation (Neil Richards); ruling-classes architecture early ideation (David Barker); merchants/workers architecture early ideation (David Barker + Neil Richards); City gates of Menaphos & Sophanem (Neil Richards); early city bridges (David Barker + Neil Richards); art-direction crib sheet (David Barker + Neil Richards). Other captions include Pharaoh designs and lower levels by David Barker; those are noted for context but not analyzed here.

**Inference:** Menaphos's visual direction and environmental design are demonstrably shared studio work with role-specific contributions. The city system includes social/economic strata reflected in distinct architecture categories, plus shared infrastructure (gates, bridges) and a city-level art-direction reference. This is an inference from labelled categories, not visual verification.

**Unknown:** How the hierarchy reads in play and which concepts reached the final game state. The crib sheet itself is reviewed below.

### Anouk Debruyne: Fort Forinthry — Runescape

Primary source: [Anouk Debruyne, Fort Forinthry - Runescape](https://anoukdebruyne.artstation.com/projects/Xg3P93).

**Artist statement and attribution:** Debruyne says her responsibilities included whiteboxing, greyboxing, overall layout, materials, modeling townhall, kitchen walls, gates and grove, set dressing, lighting and project management. She explains the fort allowed players to reclaim a part of the Wilderness and construct their own fort, requiring different building tiers and unbuilt states to share the same footprint because a shared area displays differently by player progression. She credits concept art to Neil Richards and Barkbrush. She credits Rickyct for workshop/rangers workroom/guardhouse models, interior dressing and well; Littlebigbang for Command Centre; Harrys8732 for Chapel.

**Paraphrased gallery inventory.** Upgraded, basic and intermediate civic buildings, front and back gates, interior views, woodland work spaces and an unbuilt state.

**Inference:** This is direct evidence of a gameplay-driven spatial contract: alternative progression states fit the same shared-space footprint. The model-sheet, modular kit and paintover content on Richards' page can be read alongside Debruyne's environment implementation account, but the two pages attribute different parts of the process and should not be collapsed into sole authorship. Same-footprint states create a need to preserve circulation and area boundaries through incomplete and upgraded states; this last point is a production implication, not stated verbatim.

**Unknown:** Whether every building tier uses identical internal circulation, how construction states are presented/streamed, how much is shared geometry/material vs variant geometry, and how the art was optimized for runtime.

### Jagex: Environment Art - The Golden City of Menaphos (shipped environment credit)

Primary source: [Jagex Games Studio, Environment Art - The Golden City of Menaphos](https://jagex.artstation.com/projects/RnwezO).

Jagex gives the release date as 05/06/2017 and credits environment art to Alex Rouget and Michael Blanchard. This is a useful final-environment attribution cross-check against the earlier ideation and concept pages: Richards is credited for concept/early layout/design contributions, while the shipped environment page credits Rouget and Blanchard for environment art. I have not visually inspected the final environment images, so no visual comparison is claimed.

## Visual sheet inspection completed: Jagex Menaphos style sheet

**Sheet link:** [Menaphos Art Direction / Style Sheet (David Barker & Neil Richards)](https://cdna.artstation.com/p/assets/images/images/009/166/470/large/jagex-games-studio-menaphos-art-direction.jpg?1517485975). Also documented on [Jagex's Menaphos preproduction page](https://jagex.artstation.com/projects/qGkxa), where the caption calls it “Art Direction crib sheet by David Barker & Neil Richards.”

**Visible evidence:** This single tall sheet is organized into four vertical columns labelled **Worker**, **Port**, **Merchant**, and **Imperial**. Each column pairs a representative character, a small palette/material statement, architectural examples and a textile/rug-like motif at the bottom. Worker is explicitly “Natural stone earth colours,” and shows an irregular, rough-looking, timber-supported structure; Port is “Imported materials sea colours,” with blue-forward multi-storey facade forms; Merchant is “Multi coloured warm and bright,” with a more finished pale building and red/green/gold accents; Imperial is “Blue and yellow expensive materials,” with the most ornate blue-and-yellow architectural facade. Color patches and small motif symbols accompany each category. The sheet's footer names both Barker and Richards.

**Interpretation (inference):** It functions as a cross-category visual direction sheet: social/economic identity is encoded not only by palette, but in building finish, ornament and textile pattern, while a consistent column format makes categories easy to compare. The visible worker/port/merchant/imperial sequence suggests deliberate contrast from rough/simple to ornamented/expensive; this is inferred from this sheet and should not be taken as a complete Menaphos rulebook. The figures imply related character direction, but this archive is focused on architecture.

**Unknown:** The sheet does not disclose how strictly in-game districts obey these categories, whether each architectural example is a separate kit or a paintover, how these palettes translated to final engine lighting, or which building examples were kept in the shipped layout.


## Visual sheet review: Menaphos, individual portfolio images

### “Menaphos City Buildings” sheet

Artwork: [Neil Richards — Menaphos City Buildings](https://cdna.artstation.com/p/assets/images/images/006/302/054/large/neil-richards-menaphos-city-buildings.jpg?1497530740).

The sheet combines architectural photo references across the top with grayscale concept elevations below. The drawn ensemble shows adjoining multi-storey urban facades with small windows, deep-set shutters/balconies and projecting timber structures; two tall blocks are joined by an elevated bridge, with a smaller variant at right. A person silhouette indicates scale. Handwritten callouts refer to bird's-eye messaging and livestock. A small callout near the top labels “decorative intaglios.”

**Inference:** This is a useful evidence of iteration within a shared facade language: core massing repeats, while the bridge, attached upper structures and detail distribution change. Gray concept views isolate silhouette/volume and ornament from palette; photography supplies material/form reference. It does not prove these were modular game meshes. The sheet's human scale and prop/animal notes show some attention to inhabitation and legible use, though exact gameplay intent remains unknown.

### “Menaphos City Buildings: Tombs and Temples of Light”

Artwork: [Neil Richards — Menaphos City Temples](https://cdnb.artstation.com/p/assets/images/images/006/302/079/large/neil-richards-menaphos-city-temples.jpg?1497530755).

The sheet presents grayscale concept massing for a low stepped/terraced temple and a second broad pyramidal temple with a tall colonnaded/plinth-like base. Photo references include rock-cut tomb fronts and cliff tombs, fort-like stone buildings, and excavated/rock-cut architectural fronts. A small annotation beside one entry notes that one tomb is closed at a time; other annotations point to rock carvings and mirrored limestone walls. The image includes an aqueduct / elevated arcade in the long main temple context.

**Boundary:** This is the *surface architectural study within the Menaphos city set*, not Kharid-Et archaeology or subterranean production catalog. I describe exterior/site form only.

**Inference:** The sheet distinguishes monumental civic/religious massing (broad temple platform and vertical colonnade) from smaller carved tomb-front references, while linking both to cut stone and repeated arches. It appears to explore a recognizable ancient-city vocabulary rather than a single building. Exact in-game use and interior plan are unknown.

### “Paint over 3D” / RuneFest city image

Artwork: [Neil Richards — Menaphos city / RuneFest paintover](https://cdnb.artstation.com/p/assets/images/images/006/302/073/large/neil-richards-menaphos-city-runefest.jpg?1497531704).

A high oblique painted view shows the city as a dense walled coastal settlement, with turquoise water and docks/boats along the perimeter; a large central monumental complex rises above lower block clusters, and smaller pyramidal forms, towers, walls and waterfront structures distribute around it. Clouds obscure parts of the edge; the palette uses sunlit pale stone against turquoise water and green planting.

**Inference:** This image connects landmark hierarchy with surrounding neighborhoods and shoreline infrastructure at a glance. It reads as a city-scale mood/layout communication image rather than an asset blueprint. Since Richards himself says his proposed city layouts often differ from the final, do not treat this view as authoritative shipped map evidence.

## Visual sheet review: Fort Forinthry, individual portfolio images

### “Keep Production Layout”

Artwork: [Neil Richards — Fort Keep](https://cdnb.artstation.com/p/assets/images/images/059/477/051/large/neil-richards-construction-fort.jpg?1676473344).

Front/side elevations and a ground-floor plan share the sheet with human scale and explicit material notes: roughly cut local stone; varied tiles; worn/rusted cast iron and lead edging; dark wood. Labels specify the ground floor's cooking range, sink and chest. The reverse is described as mostly mirrored to face a wall; the facade has a curved geometry below the transition. Chimneys and openings are visible in the elevation. The sheet includes a darker interior view captioned “Player Wilderness Fort Keep Interior,” with intentionally mismatched furnishings, handworn plates and smoke damage.

**Inference:** The sheet bridges architectural silhouette, practical plan, facing/visibility constraints and wear narrative. It conveys function and buildable detail while directly defining one side as mostly mirrored because it faces a wall. Material prescriptions and named use spaces support production handoff rather than mood-only concept.

### “Fort Towers”

Artwork: [Neil Richards — Fort Towers](https://cdnb.artstation.com/p/assets/images/images/059/477/089/large/neil-richards-construction-tower-design.jpg?1676473316).

A large tower elevation and smaller variation are paired with a simple interior perspective, gate-context screenshot and palette/material samples. Labels say the tower is part of the walls; the reverse is mostly mirrored; outer sides receive arrow slits and are rockier/less planted on the northern side. Interior is designated simple, with low-polygon props because “nothing happens here.” Materials repeat the keep's roughly cut local stone, worn/rusted iron and dark wood.

**Inference:** The tower sheet adapts one repeated language while varying it for defensive orientation and asset economy. The direction “nothing happens here” gives a clear reason to reserve detail for the exterior/readable role and keep low-use interior detail inexpensive; it is explicit production prioritization, not just stylistic preference.

### “Player Fort Wall” modular kit

Artwork: [Neil Richards — Player Fort Wall](https://cdnb.artstation.com/p/assets/images/images/059/477/059/large/neil-richards-construction-fort-wall-back-side.jpg?1676473290).

The sheet labels the wall as freshly cut and hastily assembled, with potential damage from Wilderness attacks. It presents three section types: wooden section with visible infill from inside the fort (wall is a facade); arched section without infill that can store blocks/barrels/spare wood; and regular section as the basic supporting wall. Multiple views include front/side detail and a scale silhouette. A greybox/paintover view on the sheet shows a partially designed courtyard wall area.

**Inference:** Modularity is explicitly tied to story/function: different wall sections preserve structural continuity while accommodating storage and visible fort-side dressing. The assembly state and potential damage make the building phase legible as an unfinished border stronghold. The storage interpretation is directly captioned; final gameplay use is not established by this sheet alone.

### “Stone Cutting Machine” production sheet

Artwork: [Neil Richards — Stone Cutting Machine](https://cdna.artstation.com/p/assets/images/images/059/477/082/large/neil-richards-construction-stone-cutting-machine-production.jpg?1676473305).

The image shows 1x1, 2x1 and 3x3 in-game examples, alongside a proposed top-down footprint, machine component views, a human scale and material labels (roughly cut local stone, stone dust, worn/rusted cast iron, wood). Text says it uses a default interact animation, should look like it can cut stone, is not an invention machine/low-tech, should reveal what it might do without animation, and that the player does not physically operate the machine. One note suggests a placement that could accommodate 12 players, though the exact condition is not fully clear at this resolution.

**Inference:** The prop is designed as a readable in-world station whose function must be communicated statically, while footprints, reuse of a standard animation and player capacity connect appearance to engine/interactivity constraints. This is more than a decorative prop sheet.

### “Chapel Window Designs”

Artwork: [Neil Richards — Chapel Windows](https://cdna.artstation.com/p/assets/images/images/059/477/048/large/neil-richards-construction-chapel-windows.jpg?1676473273).

Five circular stained-glass designs pair god symbols/names and color bands (Saradomin blue/yellow, Armadyl gold/white, Zamorak red, Zaros purple, Guthix green). A small chapel facade demonstrates a round upper window and smaller entrance glazing. Material notes specify dark/dull leading and stained glass with mixed opacity and roughness.

**Inference:** A single repeated window format accommodates multiple icon/color variants, making faction/god identity readable as a set while the material treatment is constrained. This is a concrete example of reusable architectural focal detail with variable content.

### “Keep Production Interior Ideas” paintover

Artwork: [Neil Richards — Fort Rooms Paintover](https://cdnb.artstation.com/p/assets/images/images/059/477/055/large/neil-richards-construction-fort-rooms-paintover.jpg?1676473284).

The sheet juxtaposes a more finished interior reference with game-engine/greybox overhead views, labeling the ground floor mostly storage with a few seats/game table, first floor mostly empty for standing / looking at, second floor bedroom, and top floor with brazier/flag and mortars for defense. This is a keep-specific vertical use stack rather than a generic exterior presentation.

**Inference:** Interior programming is communicated per floor with intended activity and furnishing density, which can guide camera, navigation and asset placement. It reveals a functional/defensive logic in the tower/keep section without establishing every player's exact use.

## Visual sheet review: Iaia Buildings, individual portfolio images

### Original concept and adjusted recolor

Artworks: [Iaia original architecture sketches](https://cdna.artstation.com/p/assets/images/images/048/325/666/large/neil-richards-iaia-concept-archtecture-original.jpg?1649770052) and [Iaia recolored architecture](https://cdnb.artstation.com/p/assets/images/images/048/325/657/large/neil-richards-iaia-concept-archtecture.jpg?1649769839).

The sheets show rounded, low, organic dwellings integrated with water, thick root-like supports, pools, plants and fishing activity. Some roofs resemble thatch/leaf canopies, set on compact irregular structures; a larger platform-like cluster has stairs and multiple small buildings. Human silhouettes establish comparative scale. The revised sheet labels “colourful ‘neon’ fish,” matte blue-grey clay and reflective worn enamel scales, and adjusts foliage/accents toward cooler blue-green values. The artist's page note says recoloring included red tile additions later shifted blue to balance the sky.

**Inference:** These choices support the artist's stated fish-farming/glide-diving premise: water features are architectural centerpieces, not incidental decoration; structures appear designed around pools, perches and access. The visible recolor links environmental light to material/color choices. This is a species-specific, habitat-shaped design direction, not simply a different facade style.

### “Iaia Building Top Views”

Artwork: [Iaia Building Top Views](https://cdnb.artstation.com/p/assets/images/images/048/325/649/large/neil-richards-iaia-building-top-views.jpg?1649769830).

An overhead site arrangement shows irregular pools connected through green/blue water and rooted forms. Oval and circular pool modules cluster around tree roots; small platforms and bridges allow movement between them. The page caption says these are layout-pattern ideas and root integration, with an ocean-cliff setting considered as an alternative.

**Inference:** This communicates the environment as a connected water/vegetation network with architecture arranged as nodes around ecological systems, not a street grid. The layout remains explicitly exploratory.

### “Iaia Building Kits” / prop callouts

Artwork: [Iaia architecture and prop callouts](https://cdnb.artstation.com/p/assets/images/images/048/325/675/large/neil-richards-iaia-dragon-rider-architecture.jpg?1649769859).

The sheet labels three base pool models; calls out rotation, tilt and bounded scaling for the ground plane; shows multiple pool sizes/profiles, a hut with add-ons, steps, a small niche/container and material swatches. Material names include bamboo, matte white/orange clay and shiny enamel tiles. The pool forms repeat as rounded basins with irregular colorful tile trim. Human scale is included.

**Inference:** This is a clear modular kit: a small base-model family expands into distinct pool forms and building arrangements through transforms and attachments. Material variation and repeated edge trim tie variations together. The artist's caption identifies these as callouts for 3D prop construction; final in-game implementation is unknown.

### “Iaia Building Kits: Pillars/Archways”

Artwork: [Iaia Pillars and Archways](https://cdna.artstation.com/p/assets/images/images/048/325/680/large/neil-richards-iaia-dragon-rider-architecture-pillars.jpg?1649769868).

This sheet isolates tall forked/curving supports, cap beams, chimney shapes, posts, bunting and leafy ornaments; scale figures appear by supports. Forms are organic and asymmetrical, with some enamel color marks carried across the vertical structural pieces. A note describes the post ornaments as dried leaves and herbal scents.

**Inference:** Secondary pieces extend the pool kit's soft/organic language to vertical silhouette and social/environmental dressing. They help buildings read as assembled spaces rather than only bowls and roofs.

### Iaia skybox

Artwork: [Iaia dusk skybox](https://cdnb.artstation.com/p/assets/images/images/048/325/683/large/neil-richards-skydome-iaia-dusk-clear.jpg?1649769876).

A wide panoramic sky image shows a vivid sunset glow, pink-violet clouds and a brighter horizon with small celestial bodies. The artist caption identifies this as the game location's skybox.

**Inference:** The sky is authored as a large-scale, saturated atmospheric field; the cool-shifted architectural recolor can be understood in relation to this warm/cool contrast. This is a comparison across portfolio sheets, not proof of exact in-game color management.

## Peripheral aboveground environment sheet review: The Lost Grove

Primary page: [The Lost Grove](https://zephusees.artstation.com/projects/oem14). Sheets visually reviewed: [Day paintover](https://cdna.artstation.com/p/assets/images/images/007/480/244/large/neil-richards-spec-ops-nature-temple-paintover.jpg?1506429924), [Night paintover](https://cdnb.artstation.com/p/assets/images/images/007/480/247/large/neil-richards-spec-ops-nature-temple-paintover-night.jpg?1506430117), [Magic tree](https://cdnb.artstation.com/p/assets/images/images/007/480/251/large/neil-richards-temple-tree.jpg?1506429929).

**Artist statement/credit:** Richards says the work is a 3D base made from a simple sketch for a Slayer island area, inspired by Druids and Guthix. Models by Mod_AOB. Page captions include day, night, critters and magic.

**Visible evidence:** Day and night images use the same elevated viewpoint and arrangement: a circular water/pool shrine with a central carved stone form, under dense roots and large tree trunks, with broken/overgrown masonry around its edge. Day uses warm green canopy illumination with blue-green motes and water; night shifts to a cooler, stronger teal/cyan glow with brighter points. The magic-tree sheet shows a huge floating/rooted tree form, stylized growth, hanging blue growths and carved circular stone forms nearby.

**Inference:** This is a landscape landmark rather than a town/building project. The structure feels as though the living tree encloses and partially absorbs the shrine; the day/night version preserves the place's silhouette and spatial organization while changing light/emissive accents. It is a useful adjacent example of maintaining scene recognition across lighting variants, but its limited architectural scope means it is peripheral to the urban/building research.

## Aboveground built-environment portfolio inventory and review state

This inventory uses Richards' [RuneScape Environments portfolio](https://zephusees.artstation.com/) and verified project pages. “Text/captions checked” means project prose and page labels were read. “Visual review” is reserved for image files actually opened and seen in this study.

| Project | Primary link | Scope relevance | Review state |
|---|---|---|---|
| Menaphos | [Project](https://zephusees.artstation.com/projects/BWdWl) | City-scale layouts, district palette, buildings, landmarks, props, textures | Text/captions checked; art-direction, city-buildings, temples and city-paintover sheets visually reviewed; other sheets remain unreviewed. |
| Fort Forinthry | [Project](https://zephusees.artstation.com/projects/PXaxR1) | Fort buildings, wall/tower/chapel/keep, interiors, kits | Text/captions checked; keep, tower, stone-cutting machine, wall kit, chapel windows and interior paintover sheets visually reviewed; the remaining workshop/crane/defenses are still unreviewed. |
| Iaia Buildings | [Project](https://zephusees.artstation.com/projects/wJyqGO) | Alien/ecological architecture, pools, props, building kits, skybox | Text/captions checked; original/recolor, top views, callouts, pillar and skybox sheets visually reviewed. |
| Fort Skilling Update | [Project](https://zephusees.artstation.com/projects/rJ0rlE) | Small Fort-area update; huts and gate plus tree species/planting | Text/captions checked; tree scale/species, Elder Tree options, woodcutting area, hut production/lodge tiers and gateway sheets visually reviewed. The Imcando hatchet sheet is not architecture and remains unreviewed. |
| Elf City Seren Tower of Voices | [Project](https://zephusees.artstation.com/projects/L2O0A) | Central elf-city landmark/tower | Text checked; Tower of Voices landmark sheet visually reviewed. |
| Elf Buildings (grown crystal seed) | [Project](https://zephusees.artstation.com/projects/lVLQJ) | Settlement buildings/material/fantasy construction premise | Text checked; architectural examples sheet visually reviewed. |
| Elf Buildings (first designs) | [Project](https://zephusees.artstation.com/projects/8lO0Q) | Early typology comparison | Text checked; building-variation sheet visually reviewed. |
| Pioneer House | [Project](https://zephusees.artstation.com/projects/mYbE) | Dwarven shop/forge concept | Text checked; shop/forge concept sheet visually reviewed (aboveground shop facade only; below-grade mine-plan aspects excluded). |
| Bandos Tower | [Project](https://zephusees.artstation.com/projects/yeWK) | God-themed world-event tower | Text checked; tower concept sheet visually reviewed. |
| Eastern Island Buildings | [Project](https://zephusees.artstation.com/projects/dxzXe) | Island vernacular building forms | Text/captions checked; Aminishi shipwreck houses and Waiko house/market kit sheets visually reviewed. |
| Goshima Island | [Project](https://zephusees.artstation.com/projects/4eWK8) | Fortified coastal settlement, walls/gate and water-catcher structures | Page text fetch failed initially; direct CDN images verified and visually reviewed (scene, walls/gate, water-catcher props). |
| Guthix Hall of Memories | [Project](https://zephusees.artstation.com/projects/4qkG2) | Open-air courtyard/temple garden and repeated arch structures | Layout, architecture and 3D paintover sheets visually reviewed. |
| Creepy Houses | [Project](https://zephusees.artstation.com/projects/GElB3) | Jagex creepy-house designs and associated props | House designs and prop sheet visually reviewed; Copyright Jagex. |
| Haunted Houses | [Project](https://zephusees.artstation.com/projects/J9eKa) | Gothic haunted landmark concepts | Building sheet visually reviewed; no separate page credit statement; included in Richards RuneScape Environments portfolio. |
| Ship builder | [Project](https://zephusees.artstation.com/projects/bWOn) | Shipwright building interior and work setting | Interior sheet visually reviewed; page calls it a ship-building interior and has RuneScape logo on image; no explicit page copyright statement. |`r`n| The Lost Grove | [Project](https://zephusees.artstation.com/projects/oem14) | Mostly environment/landmark with overgrown shrine, not settlement architecture | Text/captions checked; day/night and magic-tree sheets visually reviewed. Included as peripheral, not core architecture. |
| Deep Sea Fishing Update! | [Project](https://zephusees.artstation.com/projects/ZkX5x) | Supporting props, attributed to another artist | Text checked: props by Alan O'Brien. No built-environment authored by Richards evident from page; no image review, low priority for this architecture scope. |
| Jagex Environment Art — Menaphos | [Project](https://jagex.artstation.com/projects/RnwezO) | Shipped city environment, production attribution cross-check | Page text checked; credits environment art to Alex Rouget and Michael Blanchard; images not visually reviewed by this subtask. |
| Jagex Menaphos preproduction | [Project](https://jagex.artstation.com/projects/qGkxa) | Studio-wide ideation/crib-sheet authorship | Text/captions checked; visually reviewed the David Barker + Neil Richards style sheet; other gallery images not yet reviewed. |
| Anouk Debruyne, Fort Forinthry | [Project](https://anoukdebruyne.artstation.com/projects/Xg3P93) | Shipped environment and shared-footprint progression states | Text/captions checked; images not visually reviewed here. Strong source for same-footprint tier/unbuilt-state constraint; see earlier note. |

### Not in this aboveground scope

The portfolio also includes archaeology/underground/dungeon projects (Kharid-Et and Digsite, Infernal Source, Everlight, Warforge + Stormguard, Senntisten, Dungeon kits, etc.) and archaeological/prehistory material. These are intentionally left to the parallel researcher. A Menaphos temple exterior sheet was reviewed because it belongs to city-scale aboveground work; this does not expand coverage into archaeological production.

## Visual sheet review: additional aboveground environment portfolio

### Fort Skilling Update

Primary page: [Fort Skilling Update](https://zephusees.artstation.com/projects/rJ0rlE). Reviewed: [Low-level trees / scale reference](https://cdnb.artstation.com/p/assets/images/images/064/116/573/large/neil-richards-trees-scale-example.jpg?1687175447), [Elder Tree design ideas](https://cdna.artstation.com/p/assets/images/images/064/116/508/large/neil-richards-fort-skilling-elder-tree-ideas.jpg?1687175706), [woodcutting area paintover](https://cdna.artstation.com/p/assets/images/images/064/116/534/large/neil-richards-fort-skilling-update-woodcutting.jpg?1687175400), [hut production art](https://cdna.artstation.com/p/assets/images/images/064/116/518/large/neil-richards-fort-skilling-hut-production-art.jpg?1687175387), [logging lodge thumbnails](https://cdna.artstation.com/p/assets/images/images/064/116/540/large/neil-richards-fort-wood-skilling-lodge.jpg?1687175404), and [grove gateway](https://cdna.artstation.com/p/assets/images/images/064/116/512/large/neil-richards-fort-skilling-gateway-doorway.jpg?1687175380).

**Visible evidence:** Tree reference sheet compares Ash, Poplar and Oak examples against people-scale silhouettes and shows shape variation and texture blends. Elder Tree ideation presents a more ornamental/magical option against a more grounded one, with a separate high-contrast red-leaf option; handwritten notes consider cutting lower limbs, camera/roof importance and trunk character. The area paintover maps trees, water, rocks, fort structures and routes around a woodcutting zone and identifies a less dense tree area south of the Fort and an extension behind the Slayer Tower. Production hut imagery moves from blockout volumes to painted T3 hut in the grove and pairs several hut tiers with a layout diagram. The lodge comparison labels T1 “flimsy,” T2 “medium” and T3 “super,” with corresponding increase in completeness/material richness. The gate sheet specifies a 5x3 model, material set, front/inside variants, a clickspot and door offset; for an inner door it says remove shield and flag but keep torch.

**Inference:** This package extends a pre-existing fort environment with a resource-gathering district: plant species and density define spatial identity, while the huts visually show staged construction and access improvements. Tree variants are art-directed partly for composition/camera silhouettes, not purely botanical realism. The lodge tiers clearly communicate increasing stability and service; the page does not establish the precise same-footprint rule for each tier, so that should not be assumed from this comparison.

### Elf City Seren Tower of Voices

Primary page: [Elf City Seren Tower of Voices](https://zephusees.artstation.com/projects/L2O0A). Reviewed sheet: [Tower of Voices overlook](https://cdna.artstation.com/p/assets/images/images/000/220/432/large/neil-richards-elf-city-central-tower-of-voices-overlook.jpg?1411646865).

**Visible evidence:** One symmetrical landmark composition shows a very tall central spire with two flanking towers/platforms, elevated bridges and a rocky, vegetation-covered base. Thin waterfalls descend along the floating-island-like rock mass; cyan crystalline/light accents and circular halos above three towers provide recognizable focal points. Date on the sheet reads 3.3.14; page states it is the main Tower of Voices for the Elf City.

**Inference:** The composition uses a single dominant vertical landmark and paired side elements to build a legible skyline, while the natural base, foliage and waterfalls soften the transition from architecture to floating terrain. This is an early concept, not proof of final proportions or shipped layout.

### Elf Buildings — grown crystal and material alternatives

Primary pages: [Elf Buildings (grown crystal seed)](https://zephusees.artstation.com/projects/lVLQJ) and [Elf Buildings (first designs)](https://zephusees.artstation.com/projects/8lO0Q). Reviewed sheets: [Elf City architectural examples](https://cdnb.artstation.com/p/assets/images/images/000/220/433/large/neil-richards-elf-city-architectural-examples.jpg?1411646875) and [Elf building variations](https://cdnb.artstation.com/p/assets/images/images/000/220/435/large/neil-richards-elf-building-variations.jpg?1411646888).

**Visible evidence:** The architecture concepts pair pale, high-arched stone/crystal forms with green roofs, colored glass, slender turrets, pointed windows and planted terraces. Some buildings are perched on rocky outcrops with grass, small trees and water. The broader variation sheet contrasts a dark timber/plaster, steep-roofed building with white crystalline/arched forms. Richards' captions say one type is wood and plaster and the other grown from crystal seed then crafted by elven singers/craftsmen.

**Inference:** Material origin is made visible at the silhouette and construction level: organic/grown crystal buildings are thin, branching, bright and sculptural, whereas wood/plaster examples use heavier walls, dark framing and pitched roofs. Repeated pointed openings, green roof planes and planting help keep a coherent city identity across different building scales. This reading is based on concepts and artist captions; the exact lore/use of each form is not specified in detail.

### Pioneer House — Dwarven shop/forge

Primary page: [Pioneer House](https://zephusees.artstation.com/projects/mYbE). Reviewed sheet: [Pioneer quest Doric shop/mine](https://cdnb.artstation.com/p/assets/images/images/000/097/781/large/neil-richards-pioneer-quest-doric-shop-mine.jpg?1402330619).

**Visible evidence:** The sheet shows a compact stone workshop with anvil emblem, attached to a rocky hillside; a crane/hoist and vent/chimney read as working industrial features. Adjacent studies include an anvil-shaped smithing prop, forge, and small resource/workshop fixtures. Two plan-like views show distinct work areas (including a cave/mine section); those below-grade details are not analyzed here. The page calls it a Dwarven shop and forge inspired by an anvil.

**Inference:** The shop's silhouette and emblem make its use immediately legible, while equipment and work zones extend that identity into its setting. The architecture is paired with work props and layout details so the player can read it as a functional craft location rather than generic house. This project is mixed aboveground/underground; only exterior and aboveground shop/forge evidence belongs to this remit.

### Bandos Tower — goblin-built world-event landmark

Primary page: [Bandos Tower](https://zephusees.artstation.com/projects/yeWK). Reviewed sheet: [World Event Bandos Tower](https://cdna.artstation.com/p/assets/images/images/000/097/780/large/neil-richards-world-event2-bandos-tower.jpg?1402330613).

**Visible evidence:** A tall, narrow vertical pile of mismatched timber, rough masonry and scrap-like additions rises from a rocky base. Platforms, ropes, projecting beams, banners/trophies and a topmost emblem make its stacked construction visibly precarious and assembled. The page states it is a world-event tower for Bandos, made by goblins.

**Inference:** Irregular silhouette and improvised layering visually express the maker faction and an event-scale landmark, contrasting with the controlled modularity of Fort Forinthry. The page does not say the tower was built by players, nor whether the concept is final.

### Eastern Island Buildings — Aminishi and Waiko

Primary page: [Eastern Island Buildings](https://zephusees.artstation.com/projects/dxzXe). Reviewed sheets: [Aminishi buildings 1](https://cdna.artstation.com/p/assets/images/images/005/711/556/large/neil-richards-aminishi-buildings.jpg?1493205064), [Aminishi shipwreck houses](https://cdnb.artstation.com/p/assets/images/images/005/711/557/large/neil-richards-eastern-islands-aminishi-buildings2.jpg?1493205160) and [Waiko house and market kits](https://cdna.artstation.com/p/assets/images/images/005/711/558/large/neil-richards-eastern-islands-waiko-buildings.jpg?1493205072).

**Artist statement:** Richards calls these early island-building designs, including shipwreck houses and sail-covered houses, and mentions using a flat-edge brush to lay in forms quickly. Copyright Jagex.

**Visible evidence:** Aminishi sheets show repaired/reused ship hulls as shelter, sails as canopy/roof and walls, flags/ropes, ladder access and weather-beaten coastal materials. Waiko's sheet is explicitly “house and market kits”: it mixes elevated timber buildings on stone/pile bases with highly colored canvas awnings, hanging baskets/jars, stepped entrances and a tall tapered roof/tower form. Multiple roof, awning and shop configurations appear together; a small boat and goods props reinforce the market/coastal setting.

**Inference:** The same broad island setting supports local building identities: Aminishi is visually assembled from maritime salvage and fabric, while Waiko uses repeated house/market elements and colorful shade cloth to suggest bustling trade. The phrase “kit” on the Waiko sheet supports a modularity reading; Aminishi is described as early designs and need not be a production kit. Brush-speed comment indicates fast ideation for silhouette exploration, not an engine requirement.

### Goshima Island — fortified cliffside settlement

Primary page: [Goshima Island](https://zephusees.artstation.com/projects/4eWK8). Reviewed sheets: [Goshima scene](https://cdnb.artstation.com/p/assets/images/images/005/711/517/large/neil-richards-goshima.jpg?1493204928), [Goshima walls/gate](https://cdnb.artstation.com/p/assets/images/images/005/711/519/large/neil-richards-goshima-walls.jpg?1493204869) and [Goshima prop ideas](https://cdna.artstation.com/p/assets/images/images/005/711/518/large/neil-richards-goshima-prop-ideas.jpg?1493204866).

**Visible evidence:** The main scene is a fortified coastal/cliff settlement with dense stone architecture, narrow tall openings, a stair/ramp axis rising toward an inner gate, blue-green circular motifs, hanging ropes/cloth and water catchers. The artist's on-image brief labels the place a combined city and farming village with enclosed agriculture, tall narrow doorways, no figurative art, and floating water catchers; the image also shows an elevated green agricultural zone built into rock. The wall study emphasizes a tall, narrow gate set into deep stone walls with repeated round motifs, standards and hanging cloth. The prop sheet includes tall slender frame/tower-like water catchers, suspended vessels and wheel-like components.

**Inference:** The architecture reads as defensive and vertical, with steep circulation through narrow thresholds, while the agricultural shelf is integrated into the settlement's rock mass. The floating catchers and repeated blue-ring motifs form a strong shared motif system across wall, prop and settlement views. The page caption's “no figurative arts” suggests symbolic abstraction rather than literal imagery; that interpretation is strongly supported by the repeated circular/linear symbols, but function of those symbols is unknown.

**Unknown:** Goshima fetch initially failed in the page browser, but direct CDN images subsequently enabled visual review. Exact project-authorship details beyond Richards' portfolio credit, shipped status, construction system and relation to other Arc locations are not established by these sheets.


### Visual inventory note: scope and ownership

The portfolio title “Deep Sea Fishing Update!” says its props were made by “the excellent Alan” and links Alan O'Brien; it is therefore not evidence of Richards-authored architecture. “Lost Grove” attributes the 3D model work to Mod_AOB, while Richards' own stated contribution is a 3D base from a simple sketch. The Fort Forinthry, Menaphos and Iaia pages likewise include explicit multi-artist contributions. Read the images as a portfolio of credited contributions and collaboration, not sole ownership of every resulting environment.

### Guthix Hall of Memories and modular boats — boundary candidates

- [Guthix Hall of Memories](https://zephusees.artstation.com/projects/4qkG2) — visually reviewed (layout, architecture and 3D paintover). Despite the title, key evidence is an open-air courtyard/garden environment; see detailed notes above.
- [Modular boat kits](https://zephusees.artstation.com/projects/Jl8bmA) — text checked. Richards says modular kits can save production time; this Land Out of Time boat design was ultimately unused, but modularity made that effort reusable. This is a valuable non-building modular-asset production note, but no gallery image review was done because it is outside aboveground architecture.
- [Desert Props](https://zephusees.artstation.com/projects/NmLg) — text checked; caption says these are most desert props in Al Kharid. It is a prop set, not a built-environment project; individual images not reviewed.

These are not silent omissions: they are logged as lower-priority/boundary candidates. If the archive is used for broader environment-kit research, prioritize retrieving the Guthix Hall and boat galleries next.


### Guthix Hall of Memories — open-air hall/courtyard environment

Primary page: [Guthix Hall of Memories](https://zephusees.artstation.com/projects/4qkG2). Richards describes it as a mix of 2D and 3D art, mood paintings and process ordering for a smaller update (contrasted by him with Menaphos as “super tiny”). Reviewed: [layout ideas](https://cdna.artstation.com/p/assets/images/images/004/899/592/large/neil-richards-guthix-hall-of-memories-layout.jpg?1487081026), [designs](https://cdna.artstation.com/p/assets/images/images/004/899/598/large/neil-richards-guthix-hall-of-memories-designs.jpg?1487081033), [architecture designs](https://cdnb.artstation.com/p/assets/images/images/004/899/595/large/neil-richards-guthix-hall-of-memories-architecture-designs.jpg?1487081030) and [3D paintover](https://cdnb.artstation.com/p/assets/images/images/004/899/593/large/neil-richards-3d-paintover-hall-of-guthix2.jpg?1487081027).

**Visible evidence:** The layout sheet compares an open circular/curving temple complex, an explicitly “sunken temple” option, and a “trophy cabinet” plan. I exclude the sunken version from aboveground observations. Architecture thumbnails compare a dark, spiky classic temple/church and more open arcaded shrine forms. A separate kit study isolates pointed arches with mirrored pairs and an open planted bowl/tree platform. The 3D paintover shows a broad open-air paved garden/courtyard with repeated curved geometric floor patterns, multiple arches, low water/edge forms, planted central/side islands, trees and small glowing cyan fixtures. An accompanying grey 3D view shows the repeated arch/courtyard module in plan.

**Inference:** For a small update, the design explores simple, repeatable spatial motifs (circular plans, repeated arch rhythm and patterned paving) rather than many unique freestanding buildings. The open garden reads as a public memory space through a walkable contemplative layout, with planting, water and small blue focal elements integrated into architectural composition. The sheet provides a strong concept-to-greybox/paintover pairing. These are visual readings, not stated function beyond the project title.

**Unknown:** Which layout was final, whether the project was literally outdoors in the shipped game, exact player navigation/interaction, and which arch modules were reusable in final production.



### Creepy Houses — Jagex house-design/prop set

Primary page: [Creepy Houses](https://zephusees.artstation.com/projects/GElB3) (“Copyright Jagex”). Sheets: [Creepy house designs](https://cdna.artstation.com/p/assets/images/images/002/888/202/large/neil-richards-creepy-houses.jpg?1466890987) and [Creepy house props](https://cdnb.artstation.com/p/assets/images/images/002/888/203/large/neil-richards-creepy-houses-prop-sheet.jpg?1466890997).

**Visible evidence:** The building sheet compares several compact, crooked, timber-and-stone structures with steep irregular roofs, jutting upper stories, uneven supports and patches of moss/vegetation; it includes side and front variations. The prop sheet groups windows, shutters, doors, narrow shelves, banners, animal heads, hanging laundry, tables, a fireplace, barrels and stairs. Much of the architecture is dark wood with greenish stone/roof details; a few orange-lit windows provide focal points.

**Inference:** The unsettling character comes from structural distortion, accumulated attachments and asymmetry as much as from color. The companion prop sheet supports multiple local dressing combinations while retaining a shared material vocabulary. Caption states only that these are creepy house designs and props; exact in-game event use and implementation are unknown.

### Haunted Houses — gothic landmark variants

Primary page: [Haunted Houses](https://zephusees.artstation.com/projects/J9eKa). Reviewed sheet: [Haunted House Buildings](https://cdna.artstation.com/p/assets/images/images/000/325/142/large/neil-richards-haunted-house-buildings.jpg?1417187646).

**Visible evidence:** The dated sheet (6.6.14) shows several gothic building options, including a large chapel/castle-like complex with repeated pointed windows and arches, small roof towers and ivy, plus smaller floating-rock/building variants in exploratory grayscale. The main color view places the structure on a broken floating stone outcrop. A circular clock/diagram motif is inset at left. The page has no visible description/credit statement beyond inclusion in Richards' RuneScape Environments portfolio; this is visual authorship context only.

**Inference:** This is silhouette exploration for a dramatic landmark, comparing a broad connected complex to smaller isolated built masses. Broken rock supports and pointed vertical architecture amplify a floating/ruined impression. Do not read the concept sheet as evidence of a shipped location or specific gameplay.





### Ship builder — shipwright building interior

Primary page: [Ship builder](https://zephusees.artstation.com/projects/bWOn). Reviewed sheet: [Shipwright interior](https://cdnb.artstation.com/p/assets/images/images/000/096/317/large/neil-richards-plop-shipwright-interior.jpg?1402251713).

**Artist/page statement:** Page caption calls this a drawing of the interior of a ship building. There is no separate copyright statement on the page; the image itself carries a RuneScape logo and project/artist/date fields.

**Visible evidence:** A tall roofed timber-and-stone hall encloses a large ship hull under construction. The long side is open/cut away in the view, exposing multiple work levels, scaffolding, ladders, ropes, benches and shipbuilding materials. The drawing uses an axonometric cutaway to show both the building envelope and its working interior; an adjacent front view shows a more finished two-storey half-timbered facade with a wide central opening and small boats/wood stored nearby.

**Inference:** The hall is designed around ship-scale work: its height, open side, overhead framing and work platforms make the construction activity visible and spatially legible. It communicates a labor site through workshop layout and props. The image supports that reading, but production status and whether it shipped remain unknown.

