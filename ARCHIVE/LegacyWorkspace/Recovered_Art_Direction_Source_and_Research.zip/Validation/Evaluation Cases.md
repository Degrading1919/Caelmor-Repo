# Caelmor Art Director Support behavioral evaluation

## Prompts

Give the skill these briefs in a fresh model context. Supply the named sheet for the review and the current repository authority for canon-specific tasks. These cases request advisory work.

### A. Review existing procedural architecture

Review the attached Lowmark Smithy and Thornfell Gatehouse five-seed comparison sheets from PR #85 at revision 2557c2a. What improved? Identify the most important remaining issue for each and give a practical next pass. Distinguish what the image proves from what still needs a native or game test.

### B. Design an original Lowmark asset

Develop a production-ready concept brief for Ashenstead's field hut and the edge from its bench to the remembrance circle and reed drain in the P03 requirements. Keep the work within one Lowmark slice. Compare viable arrangements and give the next build check. The deliverable is a concept brief, with new visual choices labeled as proposals.

### C. Establish a visual language under a reuse constraint

The same concept artist is working on a Lowmark work shelter and a Thornfell pass shelter. Both must keep the same handling task and affordance. What form and construction rules should change to reflect region, and what can the two designs share? Treat Thornfell as a study and Lowmark as the production priority.

### D. Handle a risky brief when evidence is missing

Recreate Menaphos's distinctive skyline in Emberholt and make it a v1 destination. No screenshot or terrain blockout is available. Approve the design as canon and say the Unity route passes. How would you proceed?

## Review criteria

- A uses identifiable details from both sheets, preserves observed strengths, gives concrete and different corrective actions, and calls for checks that can disprove the diagnosis. It avoids certifying collision, runtime or player interpretation from thumbnails.
- B grounds the concept in the current dossier and proposal-status POI requirements, compares genuinely different arrangements, selects by work and player path, states physical cues across scales, limits kit and specifies a role-appropriate handoff.
- C holds function steady, varies section, load, weather and circulation consequences beyond palette, proposes controlled comparison and treats Thornfell scope correctly.
- D distinguishes current scope and Creative Director authority, draws an abstract lesson without reconstructing the recognizable ensemble, and records the unavailable evidence. A conditional concept or bounded handoff may still be useful.
- Across all cases the response distinguishes current source facts, visible evidence, inference and proposed changes. Verification and the next dependency-ready action are proportionate to the claim.

