# Validation record

## Package and private release

OpenAI Plugin Creator accepted the portable 0.1.0 ZIP as a private personal release. A readback confirmed the packaged skill, both references, the Master Protocol activation line and the updated revision check. The platform generated a Codex compatibility manifest for the stored release. The final local ZIP passed exact file membership, manifest, frontmatter, contained references, CRC and ZIP-to-source byte checks.

- [Private Caelmor Art Director Support plugin](https://chatgpt.com/plugins/plugins_6aeb3e42f8988191906722630cf7a728)
- Plugin ID: plugins_6aeb3e42f8988191906722630cf7a728
- Release ID: pluginrel_6aeb3e43bcc48191a1817a8d66d200c0
- Final local ZIP SHA-256: E121508B86936FB1DFFAD0D264F926B29F9C1285343AF6384E5EDBBCA68FB567

The Sol Medium builder discovered and installed the 0.1.0 candidate through a temporary local Codex CLI marketplace, before the final revision-check instruction was added. The package structure stayed the same. The behavioral evaluation invoked the actual skill source in fresh read-only Codex CLI sessions with the two pinned images attached. The final retest used the released skill text. Private release creation and stored file verification are complete. Automatic invocation from the user's active desktop chat was not tested.

## Behavioral results

| Case | Observed result | Assessment |
| --- | --- | --- |
| Lowmark Smithy and Thornfell Gatehouse | The initial critique preserved each building's function and visible differences but proposed Smithy stock-bay variation already present in the reviewed PR. It had used an older local checkout as the source for generator behavior. | Required revision-specific change and verification notes before prescribing changes. The focused retest recognized existing variation, clearances and the seed 91 export, and proposed testing a visible supported stock rack and the gate's approach contrast. |
| Ashenstead field hut | Compared a higher hedge-side shelter with one between the circle and drain. Selected the dry hedge approach, kept the circle at the field low point and proposed checking the bench sightline and the three field presentations in greybox. | Useful concept brief. Exact kit counts and transform allowances remain to be specified when the next build artifact is the production sheet. |
| Lowmark and Thornfell work shelters | Held the same receiving and handling task and distinguished flood adaptation from wind shelter through section, structure and access. Proposed shared interaction dimensions and matched neutral comparison. | Meets the brief. Thornfell remains a study, with Lowmark the production example. |
| Menaphos skyline request | Flagged v1 scope and canon authority, proposed a volcanic terrain and heat-driven silhouette study, and withheld a Unity result in the absence of execution. | Meets the brief. |

[Prompts and criteria](Evaluation%20Cases.md) · [Full behavioral responses](Behavioral%20Responses.md) · [Final pinned revision retest](Pinned%20Revision%20Retest.md) · [PR #85 matched evidence](https://github.com/Degrading1919/Caelmor-Repo/tree/2557c2a7103efc13522fde5376984fc5109a83f5/CODE/Scripts/architectural_generator/evidence/diversity_v12)

This evaluation covers model-assisted art direction, including review, concept, grammar and handoff. Unity traversal, native mesh changes, human recognition and Creative Director acceptance of the proposed work were outside the executed tests. Review quality depends on the supplied images and access to the correct source revision. The skill has no server dependency and uses available host tools for source retrieval.

