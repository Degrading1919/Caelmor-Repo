# Fetch the live RSMV material-name index and enrich an existing RS3 material scan.
# No model rescan, no local RuneScape cache writes, no RSMV source modification.
[CmdletBinding()]
param(
    [string]$RsmvPath = "$env:USERPROFILE\Documents\rsmv",
    [string]$CsvDirectory = "$env:USERPROFILE\Documents\RS3-Material-Usage",
    [switch]$FromElectron,
    [switch]$Redownload
)
$ErrorActionPreference = 'Stop'
$rawDir = Join-Path $CsvDirectory 'rsmv-live-names'
$rawFile = Join-Path $rawDir 'bin-67_32_0.bin'
$helper = Join-Path $PSScriptRoot 'merge-live-material-names.cjs'
$materials = Join-Path $CsvDirectory 'material_usage.csv'
$textures = Join-Path $CsvDirectory 'texture_usage.csv'

if (-not (Test-Path -LiteralPath $materials)) { throw "Missing original scan: $materials" }
if (-not (Test-Path -LiteralPath $textures)) { throw "Missing original scan: $textures" }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js is required on PATH.' }
if (-not (Test-Path -LiteralPath $helper)) { throw "Missing helper: $helper" }
New-Item -ItemType Directory -Path $rawDir -Force | Out-Null

if ($FromElectron) {
    if (-not (Test-Path -LiteralPath $rawFile)) {
        throw "Electron export not found: $rawFile`nUse the supplied Electron-Console-Live-Fetch.txt while RSMV has its LIVE cache open."
    }
    Write-Host "Using name index previously retrieved by RSMV Electron: $rawFile" -ForegroundColor Cyan
} else {
    $cli = Join-Path $RsmvPath 'dist\cli.js'
    if (-not (Test-Path -LiteralPath $cli)) {
        throw "RSMV command-line extractor not found: $cli`nCheck -RsmvPath or run npm run build in your RSMV checkout. Alternatively use -FromElectron."
    }
    if ($Redownload -or -not (Test-Path -LiteralPath $rawFile)) {
        Write-Host 'Fetching material-name index 67:32 from the live RuneScape cache via RSMV...' -ForegroundColor Cyan
        if (Test-Path -LiteralPath $rawFile) { Remove-Item -LiteralPath $rawFile -Force }
        Push-Location $RsmvPath
        try {
            # -o live invokes RSMV's own CacheDownloader, the same network backend as its Electron viewer.
            & node $cli extract -o live -s $rawDir --mode bin -i 67.32.0
            if ($LASTEXITCODE -ne 0) { throw "RSMV live extraction failed, exit code $LASTEXITCODE" }
        } finally { Pop-Location }
        if (-not (Test-Path -LiteralPath $rawFile)) {
            throw "The extractor did not produce $rawFile. Check its output and whether live cache index 67:32 exists."
        }
    } else {
        Write-Host "Reusing previously downloaded live name index: $rawFile" -ForegroundColor Cyan
        Write-Host 'Use -Redownload to fetch a fresh index.'
    }
}

& node $helper --input $rawFile --csv-dir $CsvDirectory
if ($LASTEXITCODE -ne 0) { throw "Name resolution failed, exit code $LASTEXITCODE" }
Write-Host "`nDone. Open $(Join-Path $CsvDirectory 'material_usage_named.csv') in Excel." -ForegroundColor Green
