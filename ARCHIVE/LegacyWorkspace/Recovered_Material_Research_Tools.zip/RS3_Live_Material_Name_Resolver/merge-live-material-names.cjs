'use strict';
// Use only Node core APIs. Does not read or modify the game cache or RSMV source.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function arg(flag) {
  const i = process.argv.indexOf(flag);
  if (i < 0 || !process.argv[i+1]) throw Error(`Missing argument: ${flag}`);
  return path.resolve(process.argv[i+1]);
}

// This is a direct port of RSMV src/cache/index.ts -> parseFileNameList.
function decodeNameIndex(raw) {
  if (raw.length < 8) throw Error('Name-table file is less than 8 bytes');
  const version = raw.readUInt32BE(0);
  if (version !== 1 && version !== 2) throw Error(`Unexpected name index version ${version}; expected 1 or 2`);
  const count = raw.readUInt32BE(4);
  const explicitIndex = version === 2;
  const entrySize = explicitIndex ? 8 : 4;
  const textStart = 8 + count * entrySize;
  if (!Number.isSafeInteger(textStart) || count > 5000000 || textStart > raw.length) {
    throw Error(`Implausible name-table count: ${count}; buffer bytes: ${raw.length}`);
  }
  const names = new Map();
  let cursor = 8;
  for (let i=0; i<count; i++) {
    const id = explicitIndex ? raw.readUInt32BE(cursor) : i;
    if (explicitIndex) cursor += 4;
    const offset = raw.readUInt32BE(cursor); cursor += 4;
    if (offset === 0xFFFFFFFF) continue;
    const at = textStart + offset;
    if (at < textStart || at >= raw.length) throw Error(`String offset outside buffer for material ${id}`);
    let end=at;
    while (end<raw.length && raw[end]!==0) end++;
    const value = raw.toString('latin1',at,end).trim();
    if (value) names.set(id,value);
  }
  return {version, declared:count, names};
}

function parseCSV(s) {
  s = s.replace(/^\uFEFF/, '');
  const output=[]; let cells=[], text='', quoted=false;
  for(let i=0; i<s.length; i++) {
    const c=s[i];
    if (quoted) {
      if (c==='"' && s[i+1]==='"') { text+='"'; i++; }
      else if (c==='"') quoted=false;
      else text+=c;
    } else {
      if(c==='"') quoted=true;
      else if(c===',') { cells.push(text);text=''; }
      else if(c==='\n') { cells.push(text); text='';if(cells.some(x=>x!==''))output.push(cells);cells=[]; }
      else if(c!=='\r') text+=c;
    }
  }
  if(quoted)throw Error('CSV contains an unterminated quotation');
  if(cells.length || text){cells.push(text);output.push(cells);}
  if(!output.length)throw Error('CSV is empty');
  const columns=output[0];
  const rows=output.slice(1).map((a,i)=>{
    if(a.length!==columns.length)throw Error(`CSV row ${i+2} has ${a.length} columns; expected ${columns.length}`);
    return Object.fromEntries(columns.map((h,j)=>[h,a[j]]));
  });
  return {columns, rows};
}
function readCSV(p) {return parseCSV(fs.readFileSync(p,'utf8'));}
function quote(x){return '"'+String(x??'').replace(/"/g,'""')+'"';}
function writeCSV(p, cols, rows) {
  const tmp=p+'.tmp';
  const values=[cols.map(quote).join(','),...rows.map(r=>cols.map(k=>quote(r[k])).join(','))].join('\r\n')+'\r\n';
  fs.writeFileSync(tmp,values,'utf8');
  fs.renameSync(tmp,p);
}

const known = new Map(Object.entries({
  // Directly identified Fort Forinthry samples:
  '15574':'HUMAN_SUBCOMP_WOOD_REGULAR',
  '15645':'HUMAN_STONE_BRICK_WALL_V2_DIRTY',
  '15646':'HUMAN_STONE_BRICK_WALL_V2',
  '15647':'HUMAN_STONE_BRICK_WALL_V3',
  '15649':'HUMAN_STONE_TRIM',
  '11930':'HUMAN_STONE_BASIC_BRICK',
  '11644':'HUMAN_BUILDING_DOOR_REGULAR_V2',
  '15648':'HUMAN_WOOD_WALL_REGULAR',
  '15641':'HUMAN_ROOF_TILES_SLATE_BLUE',
  '15640':'HUMAN_PLASTER_POOR_V2',
  '15642':'HUMAN_GLASS_WINDOW',
  // Additional material IDs personally identified by the Creative Director:
  '11109':'HUMAN_SUBCOMP_WOOD_POOR',
  '904':'SKINTONE_MUSCLE',
  '2377':'GRANITE',
  '1943':'CLANS_METAL_PLAIN_NO_G',
  '851':'PLATE_ARMOUR',
  '11101':'HUMAN_SUBCOMP_ROPE_POOR',
  '1516':'GRANITE_STONE_WALL_LIGHTER',
  '1562':'ENV_METAL_OBJECTS',
  '322':'CHECKERBOARD',
  '11944':'NATURAL_BONES_HUMAN',
  '2075':'WOOD',
  '11943':'HUMAN_TOWN_ROOF_FINIAL_RAILING_METAL',
  '2653':'TRUNK03',
  '3189':'HP_WOOD_GRAIN_DARK',
  '10640':'POT_WOODEN_BEAM',
  '809':'METAL_OBJECTS',
  '2090':'WOOD_OBJECTS',
  '881':'HAIR',
  '533':'LEATHER'
}));

function fromExistingNames(file, overrides) {
  if(!fs.existsSync(file))return;
  const parsed=readCSV(file);
  if(!parsed.columns.includes('MaterialID')||!parsed.columns.includes('MaterialName'))return;
  for(const row of parsed.rows){
    if(/^\d+$/.test(row.MaterialID||'') && row.MaterialName && !/^material_\d+$/.test(row.MaterialName)) {
      overrides.set(row.MaterialID,row.MaterialName);
    }
  }
}

function main() {
  const input=arg('--input'), dir=arg('--csv-dir');
  const materialFile=path.join(dir,'material_usage.csv');
  const textureFile=path.join(dir,'texture_usage.csv');
  if(!fs.existsSync(materialFile)||!fs.existsSync(textureFile))throw Error('Expected material_usage.csv and texture_usage.csv in '+dir);
  const raw=fs.readFileSync(input);
  const {version,declared,names}=decodeNameIndex(raw);
  if(!names.size)throw Error('Live cache name index decoded but contains no names');
  console.log(`Live names: ${names.size} entries (format ${version}; declared ${declared}; ${raw.length} bytes)`);
  const conflicts=[...known].filter(([id,v])=>names.has(Number(id)) && names.get(Number(id)).toUpperCase()!==v.toUpperCase());
  const matched=[...known].filter(([id,v])=>names.has(Number(id)) && names.get(Number(id)).toUpperCase()===v.toUpperCase());
  console.log(`Known-name cross-check: ${matched.length} matches; ${conflicts.length} conflicts; ${known.size-matched.length-conflicts.length} unavailable`);
  for (const [id,reference] of conflicts.slice(0,12)) console.warn(`  ID ${id}: your reference='${reference}', live='${names.get(Number(id))}'`);
  const indexCSV=path.join(dir,'rsmv_live_material_names.csv');
  writeCSV(indexCSV,['MaterialID','MaterialName'],[...names].sort((a,b)=>a[0]-b[0]).map(([MaterialID,MaterialName])=>({MaterialID,MaterialName})));
  fs.writeFileSync(path.join(dir,'rsmv_live_name_source.json'),JSON.stringify({source:'RSMV live cache index 67:32',retrievedAt:new Date().toISOString(),sha256:crypto.createHash('sha256').update(raw).digest('hex'),sizeBytes:raw.length,version,declaredEntries:declared,decodedEntries:names.size,knownIDMatches:matched.map(x=>+x[0]),knownIDConflicts:conflicts.map(([id,reference])=>({id:+id,reference,live:names.get(Number(id))}))},null,2));
  if (conflicts.length>=3 && conflicts.length>matched.length) {
    throw Error(`Live material IDs appear incompatible with your local scan (${conflicts.length} conflicts vs ${matched.length} matches). Saved the live index for investigation, but did not overwrite named scan outputs.`);
  }
  if(!matched.length)console.warn('WARNING: No known material IDs match. Treat all new live labels as unverified until compared with a confirmed model.');
  const materials=readCSV(materialFile), textures=readCSV(textureFile);
  for(const col of ['MaterialID','MaterialName','MeshOccurrences'])if(!materials.columns.includes(col))throw Error('Missing material CSV column '+col);
  if(!textures.columns.includes('RepresentativeMaterial'))throw Error('Missing texture CSV RepresentativeMaterial column');
  const userNames=new Map(known);
  fromExistingNames(materialFile,userNames);
  fromExistingNames(path.join(dir,'material_usage_named.csv'),userNames);
  const lookup=new Map(), classified=[];
  let liveResolved=0, userResolved=0, unresolved=0;
  for(const m of materials.rows){
    const id=m.MaterialID;
    let name='',source='unresolved';
    if(userNames.has(id)) {name=userNames.get(id);source='user-confirmed';userResolved++;}
    else if(names.has(Number(id))){name=names.get(Number(id));source='live-cache-name-index';liveResolved++;}
    else {name='material_'+id;unresolved++;}
    m.MaterialName=name;m.NameSource=source;lookup.set(id,name);classified.push(m);
  }
  const materialOut=path.join(dir,'material_usage_named.csv');
  writeCSV(materialOut,[...materials.columns.filter(c=>c!=='NameSource'),'NameSource'],classified);

  const byTex=new Map();
  for(const m of classified){
    if(m.NameSource==='unresolved')continue;
    for(const [channel,field] of [['diffuse','DiffuseTextureID'],['normal','NormalTextureID'],['compound','CompoundTextureID']]) {
      const id=m[field];if(!/^\d+$/.test(id||''))continue;
      const key=channel+':'+id;
      if(!byTex.has(key))byTex.set(key,[]);
      byTex.get(key).push({name:m.MaterialName,meshes:Number(m.MeshOccurrences)||0});
    }
  }
  for(const t of textures.rows) {
    const rep=t.RepresentativeMaterial||'';
    const match=/^material_(\d+)$/.exec(rep);
    if(match&&lookup.has(match[1]))t.RepresentativeMaterial=lookup.get(match[1]);
    const matches=byTex.get(t.Channel+':'+t.TextureID)||[];
    t.AssociatedNamedMaterials=matches.sort((a,b)=>b.meshes-a.meshes).slice(0,3).map(x=>x.name).join(' | ');
    t.LabelBasis=t.AssociatedNamedMaterials?'associated-material-name':'numeric-texture-id-only';
    // TextureLabel remains texture_<id>; a material name is not necessarily the texture file's intrinsic name.
  }
  const textureOut=path.join(dir,'texture_usage_named.csv');
  writeCSV(textureOut,[...textures.columns.filter(c=>c!=='AssociatedNamedMaterials'&&c!=='LabelBasis'),'AssociatedNamedMaterials','LabelBasis'],textures.rows);
  console.log(`Resolved material rows: ${liveResolved+userResolved}/${classified.length} (${liveResolved} live; ${userResolved} reference/edited; ${unresolved} unresolved)`);
  console.log(`Saved:\n  ${materialOut}\n  ${textureOut}\n  ${indexCSV}`);
}
try{main()}catch(e){console.error('ERROR: '+(e.stack||e));process.exitCode=1;}
