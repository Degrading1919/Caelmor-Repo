RS3 LIVE MATERIAL NAME RESOLVER

Purpose
-------
Resolve the material IDs counted by the previous 146,869-model scan.
Download only one material-name table from the live RuneScape cache using
RSMV's own downloader. No complete cache download, no model rescan, no GLB export.

Automatic method (recommended)
------------------------------
1. Extract this ZIP.
2. Open PowerShell in the extracted folder.
3. Run:
     Unblock-File .\Resolve-Live-RS3MaterialNames.ps1
     .\Resolve-Live-RS3MaterialNames.ps1

Default RSMV checkout: %USERPROFILE%\Documents\rsmv
Default report folder: %USERPROFILE%\Documents\RS3-Material-Usage
Customize as needed:
     .\Resolve-Live-RS3MaterialNames.ps1 -RsmvPath 'D:\wherever\rsmv'

If your execution policy still blocks the script and you trust this download:
     Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

How it works: PowerShell runs the RSMV built CLI in live mode:
  node dist/cli.js extract -o live -s <output> --mode bin -i 67.32.0
This uses the SAME CacheDownloader network backend used by RSMV's Electron
viewer; Electron itself is not required for the CLI, per RSMV's README.

If Windows/your network prevents the command-line download
----------------------------------------------------------
Use Electron-Console-Live-Fetch.txt to download the same raw index with
RSMV Electron's already-connected LIVE cache source, then run:
     .\Resolve-Live-RS3MaterialNames.ps1 -FromElectron

To fetch again:
     .\Resolve-Live-RS3MaterialNames.ps1 -Redownload

Output (original scan CSVs untouched)
-------------------------------------
material_usage_named.csv  - material IDs with live names (where available)
texture_usage_named.csv   - materials associated with each texture/channel
rsmv_live_material_names.csv - complete live material name index
rsmv_live_name_source.json  - source, hash and revision-check diagnostics
rsmv-live-names\bin-67_32_0.bin - raw table fetched from RSMV live source

Safety and interpretation
-------------------------
Live cache revisions can differ from the original Steam-cache scan. Script
cross-checks known user-identified ID/name pairs and refuses to apply
unreliable mappings if many conflicts are detected. User-confirmed names
and manually edited material_usage_named.csv names take precedence.

The name table is MATERIAL names, not intrinsic texture names. The output
preserves numeric texture IDs. A texture row includes associated named
materials but does not falsely claim that a material name is a texture name.

No modification to RuneScape cache, RSMV source, or original scan CSVs.
Uses only RSMV and Node.js; no extra npm dependencies.

Source code examined:
https://github.com/skillbert/rsmv/blob/master/src/cache/downloader.ts
https://github.com/skillbert/rsmv/blob/master/src/cache/index.ts
https://github.com/skillbert/rsmv/blob/master/src/cli.ts
