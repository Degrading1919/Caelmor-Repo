RS3 MATERIAL NAME RESOLVER — read-only, no model rescan
====================================================

Install: extract both .ps1 and .ts into the SAME folder.
Requirements: existing built RSMV checkout + Node.js and npm dependencies (as with scanner).
The tool queries RSMV's internal names index for material definitions.

Run PowerShell in the extracted folder:

  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
  .\Resolve-RS3MaterialNames.ps1

The defaults use:
 RSMV: %USERPROFILE%\Documents\rsmv
 RS3 cache: C:\Program Files (x86)\Steam\steamapps\common\RuneScape\RuneScape
 Original CSVs: %USERPROFILE%\Documents\RS3-Material-Usage
 Optional user reference folder: %USERPROFILE%\Downloads\fort_forinthry_reference

Options:
  -RsmvPath 'D:\rsmv'           Override RSMV checkout path
  -CsvDirectory 'D:\output'      Override previous scan's output folder
  -ReferenceDirectory 'D:\reference'  Read explicit material folder/file names
  -NameMapCsv 'D:\names.csv'    Optional extra verified MaterialID,MaterialName pairs
  -TryLiveNameIndex             OPTIONAL network request for missing current-game names
  -Rebuild                      Recompile helper if RSMV was updated

Output (without touching original CSVs):
  material_usage_named.csv
  texture_usage_named.csv
  rsmv_material_name_index.json

IMPORTANT:
The original model scanner already called RSMV's getInternalNameList() but
ALL rows came back as material_####. This may mean the Steam cache lacks the
necessary name index, so this resolver may not resolve more than the 11
confirmed Fort Forinthry material names. It reports its coverage honestly.
DO NOT treat texture IDs as material IDs. Texture names aren't equivalent
names; the CSV adds associated known material names, clearly marked as derived.
The optional live index can differ from the local cache build; independently
verify matches before using them as authoritative material labels.

The helper reads the cache without modifying it and never renders/models or
exports Jagex assets. Keep extracted material files private.
