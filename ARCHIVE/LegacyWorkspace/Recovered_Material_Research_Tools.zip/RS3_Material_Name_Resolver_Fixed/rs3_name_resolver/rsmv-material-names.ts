/* Read-only RSMV material-name index lookup. Does not scan models or extract assets. */
import * as fs from 'fs';
import * as path from 'path';
import { GameCacheLoader } from './cache/sqlite';
import { CacheDownloader } from './cache/downloader';
import { cacheMajors, internalNameFiles } from './constants';
import { parseFileNameList } from './cache';

type NameEntry = { id: number; name: string };
function requiredArg(flag: string): string {
  const i = process.argv.indexOf(flag);
  if (i < 0 || !process.argv[i + 1]) throw new Error(`Missing argument ${flag}`);
  return process.argv[i + 1];
}
async function loadIndex(source: any, label: string): Promise<NameEntry[]> {
  // Directly read the indexed filename resource (major 67, material index 32).
  // RSMV's CacheFileSource.getInternalNameList() uses an optional Map extension
  // which is not available in our bundled Node helper.
  const raw: Buffer = await source.getFile(cacheMajors.filenames, internalNameFiles.material);
  const names: Map<number, string> = parseFileNameList(internalNameFiles.material, raw);
  const output: NameEntry[] = [];
  for (const [id, name] of names) {
    if (Number.isSafeInteger(id) && id >= 0 && typeof name === 'string' && name.trim()) {
      output.push({ id, name: name.trim() });
    }
  }
  output.sort((a, b) => a.id - b.id);
  console.log(`${label}: ${output.length} named material definitions in RSMV's cache name index`);
  const sample = output.find(x => x.id === 15574);
  console.log(`  material 15574: ${sample?.name ?? '(not available in this name index)'}`);
  return output;
}
async function main() {
  const cache = path.resolve(requiredArg('--cache'));
  const outfile = path.resolve(requiredArg('--out'));
  if (!fs.existsSync(cache)) throw new Error(`Cache directory not found: ${cache}`);
  const allowLive = process.argv.includes('--try-live');
  let names: NameEntry[] = [];
  let sourceName = 'local-rsmv-cache';
  let diagnostic = '';
  const source = new GameCacheLoader(cache, false);
  try {
    names = await loadIndex(source, 'Local cache');
  } catch (e: any) {
    diagnostic = String(e?.message ?? e);
    console.warn(`Local name lookup unavailable: ${diagnostic}`);
  } finally { source.close(); }

  if (names.length === 0 && allowLive) {
    console.warn('Trying RSMV live name index (network access; may reflect a DIFFERENT cache revision).');
    const live = new CacheDownloader();
    try {
      names = await loadIndex(live, 'Live cache');
      if (names.length) sourceName = 'live-current-index-unverified-against-local-revision';
    } catch (e: any) {
      diagnostic += ' Live lookup failed: ' + String(e?.message ?? e);
      console.warn(diagnostic);
    } finally { live.close(); }
  }
  fs.mkdirSync(path.dirname(outfile), { recursive: true });
  const payload = { source: sourceName, count: names.length, diagnostic, names };
  const tmp = outfile + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(payload), 'utf8');
  fs.renameSync(tmp, outfile);
  if (!names.length) {
    console.warn('No official material names available from the selected cache source.');
    console.warn('The PowerShell postprocessor can still use your manually extracted reference names / optional mapping CSV.');
  }
  console.log(`Saved material name metadata: ${outfile}`);
}
main().catch((e: any) => { console.error(e?.stack ?? String(e)); process.exitCode = 1; });
