# Enrich existing RSMV scanner CSVs WITHOUT rescanning models or modifying the RS3 cache.
# Usage: .\Resolve-RS3MaterialNames.ps1
[CmdletBinding()]
param(
 [string]$RsmvPath = "$env:USERPROFILE\Documents\rsmv",
 [string]$CachePath = 'C:\Program Files (x86)\Steam\steamapps\common\RuneScape\RuneScape',
 [string]$CsvDirectory = "$env:USERPROFILE\Documents\RS3-Material-Usage",
 [string]$ReferenceDirectory = "$env:USERPROFILE\Downloads\fort_forinthry_reference",
 [string]$NameMapCsv = '',
 [switch]$TryLiveNameIndex,
 [switch]$Rebuild
)
$ErrorActionPreference = 'Stop'
$materialCsv = Join-Path $CsvDirectory 'material_usage.csv'
$textureCsv = Join-Path $CsvDirectory 'texture_usage.csv'
if (-not (Test-Path -LiteralPath $materialCsv)) { throw "Missing original CSV: $materialCsv" }
if (-not (Test-Path -LiteralPath $textureCsv)) { throw "Missing original CSV: $textureCsv" }
if (-not (Test-Path -LiteralPath (Join-Path $RsmvPath 'webpack.config.js'))) { throw "RSMV checkout not found: $RsmvPath" }
if (-not (Test-Path -LiteralPath (Join-Path $RsmvPath 'node_modules\webpack\bin\webpack.js'))) { throw "RSMV dependencies missing; run npm install in $RsmvPath" }
if (-not (Test-Path -LiteralPath $CachePath)) { throw "Cache path missing: $CachePath" }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js missing on PATH' }

# Compile a small *read-only* RSMV helper in the existing checkout.
$helper = Join-Path $PSScriptRoot 'rsmv-material-names.ts'
if (-not (Test-Path -LiteralPath $helper)) { throw "Missing helper beside script: $helper" }
$targetCompiled = Join-Path $RsmvPath 'dist\caelmor_material_names.js'
# Recompile the small helper on every invocation to avoid stale bundles from earlier attempts.
if ($true) {
 $tmpTs = Join-Path $RsmvPath 'src\__caelmor_material_names.ts'
 $tmpConfig = Join-Path $RsmvPath '__caelmor_material_names.webpack.cjs'
 if ((Test-Path -LiteralPath $tmpTs) -or (Test-Path -LiteralPath $tmpConfig)) {
  throw 'Temporary name-resolver build files exist in RSMV. Move them before continuing.'
 }
 try {
  Copy-Item -LiteralPath $helper -Destination $tmpTs
  @'
const base = require('./webpack.config.js');
module.exports = {
  ...base,
  entry: { caelmor_material_names: './src/__caelmor_material_names.ts' },
  plugins: [],
  output: { ...base.output, filename: '[name].js' }
};
'@ | Set-Content -LiteralPath $tmpConfig -Encoding UTF8
  Push-Location $RsmvPath
  try {
   & node (Join-Path $RsmvPath 'node_modules\webpack\bin\webpack.js') --config $tmpConfig --mode development
   if ($LASTEXITCODE -ne 0) { throw "Webpack failed: $LASTEXITCODE" }
  } finally { Pop-Location }
 } finally {
  if (Test-Path -LiteralPath $tmpTs) { Remove-Item -LiteralPath $tmpTs -Force }
  if (Test-Path -LiteralPath $tmpConfig) { Remove-Item -LiteralPath $tmpConfig -Force }
 }
}

# Query material name index, rather than decoded models. No cache write operations.
$nameJson = Join-Path $CsvDirectory 'rsmv_material_name_index.json'
$nodeArgs = @($targetCompiled, '--cache', $CachePath, '--out', $nameJson)
if ($TryLiveNameIndex) { $nodeArgs += '--try-live' }
& node @nodeArgs
if ($LASTEXITCODE -ne 0) { throw "RSMV name-index lookup failed: $LASTEXITCODE" }
$index = Get-Content -LiteralPath $nameJson -Raw -Encoding UTF8 | ConvertFrom-Json
$names = @{}
$sources = @{}
foreach ($entry in $index.names) {
 $key = [string]$entry.id
 if (-not [string]::IsNullOrWhiteSpace([string]$entry.name)) {
  $names[$key] = [string]$entry.name
  $sources[$key] = [string]$index.source
 }
}

# Explicitly confirmed Fort Forinthry material IDs from your extracted source data.
# These are evidence-backed overrides, NOT guesses for unnamed entries.
$known = @{
 '15574'='HUMAN_SUBCOMP_WOOD_REGULAR'
 '15645'='HUMAN_STONE_BRICK_WALL_V2_DIRTY'
 '15646'='HUMAN_STONE_BRICK_WALL_V2'
 '15647'='HUMAN_STONE_BRICK_WALL_V3'
 '15649'='HUMAN_STONE_TRIM'
 '11930'='HUMAN_STONE_BASIC_BRICK'
 '11644'='HUMAN_BUILDING_DOOR_REGULAR_V2'
 '15648'='HUMAN_WOOD_WALL_REGULAR'
 '15641'='HUMAN_ROOF_TILES_SLATE_BLUE'
 '15640'='HUMAN_PLASTER_POOR_V2'
 '15642'='HUMAN_GLASS_WINDOW'
}
foreach ($key in $known.Keys) { $names[$key]=$known[$key]; $sources[$key]='confirmed-user-reference' }

# Read names encoded in file/folder titles such as 'material_15574 (HUMAN_SUBCOMP_WOOD_REGULAR)'.
if (Test-Path -LiteralPath $ReferenceDirectory) {
 Get-ChildItem -LiteralPath $ReferenceDirectory -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.Name -match '(?i)^material[_-](\d+)\s*\(([^)]+)\)') {
   $key = $Matches[1]
   $value = $Matches[2].Trim()
   if ($value) { $names[$key] = $value; $sources[$key] = 'local-reference-name' }
  }
 }
}

# Optional explicit mapping CSV columns: MaterialID,MaterialName
if ($NameMapCsv) {
 if (-not (Test-Path -LiteralPath $NameMapCsv)) { throw "Missing name mapping: $NameMapCsv" }
 foreach ($entry in (Import-Csv -LiteralPath $NameMapCsv)) {
  $key = [string]$entry.MaterialID
  $value = [string]$entry.MaterialName
  if ($key -match '^\d+$' -and -not [string]::IsNullOrWhiteSpace($value)) {
   $names[$key] = $value.Trim(); $sources[$key] = 'user-name-map'
  }
 }
}

$materials = @(Import-Csv -LiteralPath $materialCsv)
$materialLookup = @{}
$resolved = 0
foreach ($row in $materials) {
 $id = [string]$row.MaterialID
 $name = if ($names.ContainsKey($id)) { $names[$id] } else { "material_$id" }
 $src = if ($names.ContainsKey($id)) { $sources[$id] } else { 'unresolved' }
 if ($src -ne 'unresolved') { $resolved++ }
 $row.MaterialName = $name
 $row | Add-Member -MemberType NoteProperty -Name NameSource -Value $src -Force
 $materialLookup[$id] = $name
}
$materialOutput = Join-Path $CsvDirectory 'material_usage_named.csv'
$materials | Export-Csv -LiteralPath $materialOutput -NoTypeInformation -Encoding UTF8

# Texture IDs do not have the same name index as materials.
# Show a traceable associated material name, NEVER pretend it is an intrinsic texture filename.
$textures = @(Import-Csv -LiteralPath $textureCsv)
$related = @{}
foreach ($row in $materials) {
 foreach ($pair in @([pscustomobject]@{Field='DiffuseTextureID';Channel='diffuse'},[pscustomobject]@{Field='NormalTextureID';Channel='normal'},[pscustomobject]@{Field='CompoundTextureID';Channel='compound'})) {
  $tid = [string]$row.($pair.Field); $channel=$pair.Channel
  if (-not $tid -or $tid -notmatch '^\d+$') { continue }
  if ($row.NameSource -eq 'unresolved') { continue }
  $key = "$channel`:$tid"
  if (-not $related.ContainsKey($key)) { $related[$key] = New-Object 'System.Collections.Generic.List[object]' }
  $related[$key].Add([pscustomobject]@{ Name=$row.MaterialName; MeshCount=[long]$row.MeshOccurrences })
 }
}
foreach ($row in $textures) {
 $rep = [string]$row.RepresentativeMaterial
 if ($rep -match '^material_(\d+)$') {
  $repId = $Matches[1]
  if ($materialLookup.ContainsKey($repId)) { $row.RepresentativeMaterial=$materialLookup[$repId] }
 }
 $key = "$($row.Channel):$($row.TextureID)"
 $shared = if ($related.ContainsKey($key)) {
  @($related[$key] | Sort-Object MeshCount -Descending | Select-Object -First 3 | ForEach-Object { $_.Name }) -join ' | '
 } else { '' }
 $row | Add-Member -MemberType NoteProperty -Name AssociatedNamedMaterials -Value $shared -Force
 $row | Add-Member -MemberType NoteProperty -Name LabelBasis -Value $(if($shared){'derived-from-associated-material'}else{'numeric-texture-id-only'}) -Force
}
$textureOutput = Join-Path $CsvDirectory 'texture_usage_named.csv'
$textures | Export-Csv -LiteralPath $textureOutput -NoTypeInformation -Encoding UTF8

Write-Host "`nMaterial names resolved: $resolved / $($materials.Count)" -ForegroundColor Cyan
Write-Host "RSMV name index entries: $($index.count) (source: $($index.source))"
Write-Host "Material CSV: $materialOutput" -ForegroundColor Green
Write-Host "Texture CSV:  $textureOutput" -ForegroundColor Green
if ([int]$index.count -eq 0) {
 Write-Warning 'No names were returned. Inspect the diagnostic above to distinguish a missing name resource from a decoder or cache error. Only explicitly verified reference names were applied.'
 Write-Warning 'You may try -TryLiveNameIndex (network) or add another MaterialID,MaterialName mapping CSV. Live IDs may be from a different game build; verify them before use.'
}
