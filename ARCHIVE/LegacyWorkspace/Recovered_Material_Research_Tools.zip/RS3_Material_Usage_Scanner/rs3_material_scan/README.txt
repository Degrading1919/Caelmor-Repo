RS3 Model Cache Material Usage Scanner (Caelmor research)
======================================================
Read-only research helper for an existing skillbert/rsmv checkout.
The PowerShell launcher builds a TypeScript helper using RSMV's installed
webpack, then uses RSMV's native NXT cache parser and material decoders.
No extra npm package is required if RSMV already runs.

1. Unzip these files together anywhere you like.
2. Open PowerShell in that folder.
3. Test a 500-model sample (default):
   .\Scan-RS3MaterialUsage.ps1
4. Open Documents\RS3-Material-Usage\texture_usage.csv in Excel.
5. To scan all remaining models:
   .\Scan-RS3MaterialUsage.ps1 -MaxModels 0
6. Run the same command again after interruption to resume.
7. To start again from scratch:
   .\Scan-RS3MaterialUsage.ps1 -MaxModels 0 -Reset

If the RSMV checkout is not at Documents\rsmv:
   .\Scan-RS3MaterialUsage.ps1 -RsmvPath 'D:\path\to\rsmv'

If the RSMV source has been updated, add -Rebuild.

OUTPUTS
- texture_usage.csv: one row per (channel, texture ID); sortable.
- material_usage.csv: human-readable material names and usage.
- model_material_sightings.csv: appended per-model per-material observations.
- scan_state.json: automatically saved checkpoint for resuming.

COLUMNS
- ModelCount: number of distinct decoded models referencing an entry.
- MeshOccurrences: number of render mesh parts referencing an entry.
- TriangleOccurrences: summed triangle counts of those mesh parts; not world-space area.
- MaterialCount: number of distinct materials using a texture/channel pair.
- TextureLabel: numeric fallback, since RSMV's cache doesn't expose reliable
  human-readable names for every underlying texture file.
- RepresentativeMaterial: most frequently associated named material.

SCOPE / LIMITATIONS
- Counts locally cached models, NOT placed world instances and NOT only architecture.
- Models with absent, hidden, untextured, or undecodable mesh parts don't contribute
  to the texture totals. Decode failures are logged.
- No game cache data is modified and no Jagex meshes/textures are exported.
- The script is provided from static code inspection of RSMV, not tested against
  your local Steam cache; run 500 models first and report any exceptions.
- Keep extracted names and analytics private if redistributing raises concerns.
