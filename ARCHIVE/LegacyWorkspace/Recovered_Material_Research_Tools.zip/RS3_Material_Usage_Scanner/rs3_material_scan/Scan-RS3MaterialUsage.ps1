# Read-only RS3 cache material/texture usage scan using RSMV source decoders.
# Keep this PS1 beside rsmv-material-usage.ts. Requires a built RSMV checkout.
[CmdletBinding()]
param(
 [string]$RsmvPath = "$env:USERPROFILE\Documents\rsmv",
 [string]$CachePath = 'C:\Program Files (x86)\Steam\steamapps\common\RuneScape\RuneScape',
 [string]$OutputDirectory = "$env:USERPROFILE\Documents\RS3-Material-Usage",
 [ValidateRange(0,2147483647)][int]$MaxModels = 500,
 [ValidateRange(1,100000)][int]$CheckpointEvery = 250,
 [switch]$Reset,
 [switch]$Rebuild
)
$ErrorActionPreference = 'Stop'
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js not found on PATH.' }
if (-not (Test-Path -LiteralPath (Join-Path $RsmvPath 'webpack.config.js'))) { throw "RSMV source checkout not found: $RsmvPath" }
if (-not (Test-Path -LiteralPath (Join-Path $RsmvPath 'node_modules\webpack\bin\webpack.js'))) { throw 'RSMV dependencies are missing. Run npm install in your RSMV folder first.' }
if (-not (Test-Path -LiteralPath $CachePath)) { throw "Cache folder not found: $CachePath" }
$helper = Join-Path $PSScriptRoot 'rsmv-material-usage.ts'
if (-not (Test-Path -LiteralPath $helper)) { throw "Place rsmv-material-usage.ts beside this PowerShell script: $PSScriptRoot" }
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
if ($Reset) {
 foreach($filename in @('scan_state.json','texture_usage.csv','material_usage.csv','model_material_sightings.csv')) {
  $target = Join-Path $OutputDirectory $filename
  if(Test-Path -LiteralPath $target){ Remove-Item -LiteralPath $target -Force }
 }
}
$compiled=Join-Path $RsmvPath 'dist\caelmor_material_scan.js'
if ($Rebuild -or -not (Test-Path -LiteralPath $compiled)) {
 $targetTs=Join-Path $RsmvPath 'src\__caelmor_material_scan.ts'
 $targetConfig=Join-Path $RsmvPath '__caelmor_material_scan.webpack.cjs'
 $webpackScript=Join-Path $RsmvPath 'node_modules\webpack\bin\webpack.js'
 if ((Test-Path -LiteralPath $targetTs) -or (Test-Path -LiteralPath $targetConfig)) { throw 'Temporary scanner build filenames already exist in the RSMV checkout. Rename them before running.' }
 try {
  Copy-Item -LiteralPath $helper -Destination $targetTs
  @'
const base = require('./webpack.config.js');
module.exports = {
  ...base,
  entry: { caelmor_material_scan: './src/__caelmor_material_scan.ts' },
  plugins: [],
  output: { ...base.output, filename: '[name].js' }
};
'@ | Set-Content -LiteralPath $targetConfig -Encoding UTF8
  Push-Location $RsmvPath
  try {
   & node $webpackScript --config $targetConfig --mode development
   if ($LASTEXITCODE -ne 0) { throw "Webpack failed with exit code $LASTEXITCODE" }
  } finally { Pop-Location }
 } finally {
  if(Test-Path -LiteralPath $targetTs){Remove-Item -LiteralPath $targetTs -Force}
  if(Test-Path -LiteralPath $targetConfig){Remove-Item -LiteralPath $targetConfig -Force}
 }
}
Write-Host "Running read-only scan (MaxModels: $MaxModels). Use 0 to scan all remaining indexed models." -ForegroundColor Cyan
& node $compiled --cache $CachePath --out $OutputDirectory --max-models $MaxModels --checkpoint $CheckpointEvery
if ($LASTEXITCODE -ne 0) { throw "Scan failed with exit code $LASTEXITCODE" }
Write-Host "`nOpen $(Join-Path $OutputDirectory 'texture_usage.csv') in Excel and sort by MeshOccurrences." -ForegroundColor Green
