/* Caelmor research helper: read-only model->material->texture inventory.
   Uses RSMV's own local-cache decoder; outputs metadata only, never images/assets.
*/
import * as fs from 'fs';
import * as path from 'path';
import { GameCacheLoader } from './cache/sqlite';
import { EngineCache } from './3d/modeltothree';
import { cacheMajors, internalNameFiles } from './constants';
import { parse } from './parser/jsondecoders';

type MaterialCount = { materialId:number, materialName:string, models:number, meshes:number, triangles:number, diffuseId:number|null, normalId:number|null, compoundId:number|null };
type TextureCount = { textureId:number, channel:string, models:number, meshes:number, triangles:number, materialRefs:Record<string,number> };
type Snapshot = { format:number, cachePath:string, lastModelId:number, attempted:number, completed:number, failed:number, materials:MaterialCount[], textures:TextureCount[] };

function arg(key:string, fallback:string):string { let i=process.argv.indexOf(key); return i<0?fallback:process.argv[i+1] || fallback; }
function numberArg(key:string, fallback:number):number { let n=Number(arg(key,String(fallback))); if (!Number.isSafeInteger(n)||n<0) throw new Error(`Invalid ${key}: ${n}`); return n; }
function csvCell(x:unknown):string { return '"'+String(x??'').replace(/"/g,'""')+'"'; }
function csvLine(x:unknown[]):string { return x.map(csvCell).join(',')+'\n'; }
function atomicText(filename:string,body:string) { const temp=filename+'.tmp'; fs.writeFileSync(temp,body,'utf8'); try { fs.renameSync(temp,filename); } catch { if(fs.existsSync(filename))fs.rmSync(filename);fs.renameSync(temp,filename); } }
function csvFile(filename:string,head:string[],rows:unknown[][]){atomicText(filename,csvLine(head)+rows.map(csvLine).join(''));}
function push(a:Map<string,TextureCount>, key:string, f:()=>TextureCount):TextureCount {let row=a.get(key);if(!row){row=f();a.set(key,row);}return row;}

async function main() {
 const cachePath=path.resolve(arg('--cache',''));
 const outputPath=path.resolve(arg('--out',''));
 const maxModels=numberArg('--max-models',0);
 const checkpointEvery=Math.max(1,numberArg('--checkpoint',250));
 if (!cachePath || !fs.existsSync(cachePath)) throw new Error(`Cache folder not found: ${cachePath}`);
 fs.mkdirSync(outputPath,{recursive:true});
 const statePath=path.join(outputPath,'scan_state.json');
 const materialPath=path.join(outputPath,'material_usage.csv');
 const texturePath=path.join(outputPath,'texture_usage.csv');
 const sightingPath=path.join(outputPath,'model_material_sightings.csv');
 let state:Snapshot={format:1,cachePath,lastModelId:-1,attempted:0,completed:0,failed:0,materials:[],textures:[]};
 if(fs.existsSync(statePath)) {
  state=JSON.parse(fs.readFileSync(statePath,'utf8')) as Snapshot;
  if(state.format!==1 || path.resolve(state.cachePath).toLowerCase()!==cachePath.toLowerCase()) throw new Error('Checkpoint belongs to a different cache or scanner format. Use a fresh output directory or -Reset.');
 }
 if(!fs.existsSync(sightingPath) && state.attempted!==0) throw new Error('Checkpoint exists without sighting CSV. Use -Reset or a new output directory.');
 if(!fs.existsSync(sightingPath))fs.writeFileSync(sightingPath,csvLine(['ModelID','MaterialID','MaterialName','MeshOccurrences','Triangles','DiffuseTextureID','NormalTextureID','CompoundTextureID']));
 const mats=new Map<number,MaterialCount>(state.materials.map(x=>[x.materialId,x]));
 const texs=new Map<string,TextureCount>(state.textures.map(x=>[`${x.channel}:${x.textureId}`,x]));
 let pending:string[]=[]; let sinceCheckpoint=0;let thisRun=0; let stopping=false;
 process.on('SIGINT',()=>{stopping=true;console.log('Stopping after current model; checkpoint will be written.');});
 let lastError='';
 function checkpoint(){
  if(pending.length){fs.appendFileSync(sightingPath,pending.join(''),'utf8');pending=[];}
  state.materials=[...mats.values()];state.textures=[...texs.values()];
  csvFile(materialPath,['MaterialID','MaterialName','ModelCount','MeshOccurrences','TriangleOccurrences','DiffuseTextureID','NormalTextureID','CompoundTextureID'],state.materials.sort((a,b)=>b.meshes-a.meshes||b.models-a.models).map(x=>[x.materialId,x.materialName,x.models,x.meshes,x.triangles,x.diffuseId,x.normalId,x.compoundId]));
  csvFile(texturePath,['TextureID','TextureLabel','Channel','ModelCount','MeshOccurrences','TriangleOccurrences','RepresentativeMaterial','MaterialCount'],state.textures.sort((a,b)=>b.meshes-a.meshes||b.models-a.models).map(t=>{
    const ranked=Object.entries(t.materialRefs).sort((a,b)=>b[1]-a[1]); const primary=ranked.length?mats.get(+ranked[0][0]):undefined;
    return [t.textureId,`texture_${t.textureId}`,t.channel,t.models,t.meshes,t.triangles,primary?.materialName??'',ranked.length];
  }));
  atomicText(statePath,JSON.stringify(state,null,2));sinceCheckpoint=0;
  console.log(`Checkpoint: ${state.attempted} attempted; ${state.completed} decoded; ${state.failed} failed; ${mats.size} materials; ${texs.size} texture/channel pairs`);
 }
 console.log('Opening local RS3 cache READ ONLY:',cachePath);
 const source=new GameCacheLoader(cachePath,false);
 try {
  const engine=await EngineCache.create(source);
  const materialNames=await source.getInternalNameList(internalNameFiles.material).catch(()=>new Map<number,string>());
  const indices=await source.getCacheIndex(cacheMajors.models);
  const modelIds=indices.filter((x:any)=>!!x).map((x:any)=>Number(x.minor)).filter(Number.isSafeInteger).sort((a:number,b:number)=>a-b);
  const pendingIds=modelIds.filter((id:number)=>id>state.lastModelId);
  const batch=maxModels===0?pendingIds:pendingIds.slice(0,maxModels);
  console.log(`Indexed models: ${modelIds.length}; remaining: ${pendingIds.length}; selected this run: ${batch.length}`);
  const materialInfo=new Map<number,{name:string,textureIds:Record<string,number>}>();
  function material(id:number){
    let info=materialInfo.get(id);
    if(!info){
      const name=materialNames.get(id) || `material_${id}`;
      const data=engine.getMaterialData(id);
      const ids:Record<string,number>={};
      for(const channel of ['diffuse','normal','compound'] as const){const x=data.textures[channel];if(typeof x==='number'&&x>=0) ids[channel]=x;}
      info={name,textureIds:ids};materialInfo.set(id,info);
    }
    return info;
  }
  for(const id of batch){
   let err='';
   try {
    const binary=await source.getFileById(cacheMajors.models,id);
    const parsed=parse.models.read(binary,source);
    const oneModel=new Map<number,{meshes:number,triangles:number}>();
    const note=(materialId:unknown,indices:unknown,hidden:unknown)=>{
      const mid=Number(materialId);
      if(hidden || !Number.isSafeInteger(mid) || mid<0)return;
      const n=typeof indices==='number'?indices:(indices as any)?.length??0;
      const tris=Math.floor(Number(n)/3);
      if(!Number.isFinite(tris)||tris<=0)return;
      const existing=oneModel.get(mid)??{meshes:0,triangles:0};existing.meshes+=1;existing.triangles+=tris;oneModel.set(mid,existing);
    };
    if(parsed.meshes){for(const mesh of parsed.meshes)note(mesh.material,mesh.indexBuffers?.[0],mesh.isHidden);}
    else if(parsed.meshdata?.renders){for(const render of parsed.meshdata.renders)note(render.material,render.buf,render.isHidden);}
    const seenTexture=new Set<string>();
    for(const [mid,usage] of oneModel){
      const info=material(mid);const ids=info.textureIds;
      let m=mats.get(mid);if(!m){m={materialId:mid,materialName:info.name,models:0,meshes:0,triangles:0,diffuseId:ids.diffuse??null,normalId:ids.normal??null,compoundId:ids.compound??null};mats.set(mid,m);}
      m.models+=1;m.meshes+=usage.meshes;m.triangles+=usage.triangles;
      pending.push(csvLine([id,mid,info.name,usage.meshes,usage.triangles,ids.diffuse??null,ids.normal??null,ids.compound??null]));
      for(const [channel,tid] of Object.entries(ids)){
        const key=`${channel}:${tid}`;
        const t=push(texs,key,()=>({textureId:tid,channel,models:0,meshes:0,triangles:0,materialRefs:{}}));
        if(!seenTexture.has(key)){t.models++;seenTexture.add(key);}
        t.meshes+=usage.meshes;t.triangles+=usage.triangles;
        t.materialRefs[mid]=(t.materialRefs[mid]||0)+usage.meshes;
      }
    }
    state.completed++;
   } catch(e:any){state.failed++;err=String(e?.message??e);lastError=err;if(state.failed<=10) console.warn(`Model ${id} skipped: ${err}`);}
   state.attempted++;state.lastModelId=id;sinceCheckpoint++;thisRun++;
   if(sinceCheckpoint>=checkpointEvery){checkpoint();}
   if(stopping) break;
  }
  checkpoint();
  console.log('Finished this run. Ranked CSV:',texturePath);
  if(state.failed)console.log(`Decode failures: ${state.failed}. Latest: ${lastError||'previous run'}. These are excluded from counts.`);
  if(maxModels&&pendingIds.length>thisRun)console.log('Run the same PowerShell command again to resume the remaining cache.');
 } finally {source.close();}
}
main().catch((err:any)=>{console.error(err?.stack??String(err));process.exitCode=1;});
