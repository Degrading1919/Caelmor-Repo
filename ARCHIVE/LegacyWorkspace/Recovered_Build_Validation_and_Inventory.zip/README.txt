CAELMOR PLAYABLE FOUNDATION - CLICK TO MOVE

Run Caelmor.exe with Caelmor_Data, MonoBleedingEdge, and all bundled engine files beside it.
Left-click navigable terrain: move. Click again: replace destination. Shift: sprint. E: interact.
Right mouse: orbit. Wheel: zoom. Escape: stop route/help/quit. F3: optional WASD debug controls (off by default).

The host plans complete obstacle-avoiding routes and validates collision at 10 Hz. Invalid clicks preserve a valid existing route. A new physical blocker stops movement safely.
Approach the amber marker, then press E. The HUD shows committed host ticks, position, and interaction state.

Technical greybox for Lowmark integration. No authored quest, rewards, durable saves, or network co-op are loaded. Sessions reset on exit.

Verified: licensed Unity scene/baked NavMesh checks, Windows build, standalone automated navigation/gameplay smoke (12 authoritative ticks in 1.15 seconds), plus interactive terrain clicking, arrival, obstacle navigation, E interaction, and HUD click exclusion.

Authoritative source: C:\Users\CK\Documents\Caelmor-Repo and Degrading1919/Caelmor-Repo.
This Caelmor-Build folder is generated output. Legacy Caelmor data was preserved additively in repository archives; originals remain untouched.
Reproduce from repository:
  .\CODE\Build-And-Validate.ps1
  .\UNITY\Build.ps1
