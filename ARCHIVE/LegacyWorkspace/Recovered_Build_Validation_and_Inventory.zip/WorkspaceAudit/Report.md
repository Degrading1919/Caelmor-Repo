# Caelmor workspace source comparison

Authoritative source: `C:/Users/CK/Documents/Caelmor-Repo` and `Degrading1919/Caelmor-Repo`. Generated build output: `C:/Users/CK/Documents/Caelmor-Build`. Legacy reference: `C:/Users/CK/Documents/Caelmor`.

This inspection made no changes to legacy or repository files. Reports are generated output. It did not use Git history, configuration, remotes, or credentials to classify files; all filesystem differences are conservatively treated as potentially useful local work.

## Inventory

Legacy tree contains 29,907 files / 1,934,036,889 bytes. Of those, 29,538 files / 1,926,662,812 bytes are Unity `Library`, `Logs`, and `UserSettings` generated output. Four Unity Version Control metadata files (13,979 bytes) are excluded from the source inventory. The remaining 365 files total 7,360,098 bytes. SHA-256 was streamed over source files and repository source files to detect both relative-path and relocated duplicates.

- 147 files match the corresponding repository path exactly.
- 48 files have the same path and different contents; they include older governance/canon and runtime code. The authoritative copies must not be overwritten automatically.
- 4 files exactly match files under another repository path: one NPC template `.txt` -> `.md`, and three Unity settings files.
- 166 files have unique path/content combinations: 99 in historical `ARCHIVE`, 60 in the old Unity template/settings, and 7 other source/reference files. One of those seven (the MMO technical brief) is content-equivalent to the repository's renamed brief after trimming outer whitespace, leaving six distinct additional reference/test documents.

## Legacy Unity project

`UNITY/Caelmor_VS` is an old URP Empty Template. Its SampleScene contains Main Camera, Directional Light, and Global Volume. `Assets/Caelmor` is empty apart from the folder metadata. The only scripts are stock tutorial Readme/ReadmeEditor, and the only texture is the tutorial URP icon. No custom art, model, authored gameplay scene, or game script was found there. Template project settings/packages/input maps are retained in the legacy directory, not adopted into the current built-in-render-pipeline project.

## Safe reconciliation candidates

Archive the missing historical material under the existing `ARCHIVE` category, without making it runtime/canon authority. Do not place older `.cs` into live `CODE/Systems` or `DESIGNS/Networking & Persistence`, which are included in the executable build. Ignore `desktop.ini`; do not copy Unity caches, Version Control metadata, or template assets into the active Unity project.

The six other distinct references/test documents can be preserved under `ARCHIVE/LegacyWorkspace/<original relative path>`. Same-path differing files remain in the untouched legacy directory pending any deliberate content review. Deleting or moving legacy data or its caches requires explicit Director approval.

## Evidence files

`comparison.json`, `legacy-source-inventory.json`, and `repository-source-inventory.json` record original relative paths, byte counts, SHA-256 values, and classification. This is a point-in-time source comparison while active Unity implementation work may continue in the repository.

## Authorized reconciliation result

After the read-only comparison, the Technical Director authorized additive historical preservation. All 152 selected files were copied without replacing active files: 98 missing existing archival files, six additional historical reference/test documents, and 48 same-path historical variants. Total preserved bytes: 2,190,822. Each copied file matched its original SHA-256; all 365 inventoried legacy source hashes were then rechecked and remained unchanged. No legacy source was deleted, overwritten, relocated, or edited.

The preserved-file inventory is `C:/Users/CK/Documents/Caelmor-Repo/ARCHIVE/LegacyWorkspace/SourceInventory.json`; its README explicitly labels archived assistant instructions, schemas and code as historical reference, outside active build authority. Files already historically categorized under ARCHIVE retain their existing relative archive paths; other variants are under ARCHIVE/LegacyWorkspace with their original relative paths. Generated output and old stock Unity template assets remain unimported and untouched. Cleanup/removal/relocation of the legacy directory still requires explicit Director approval.
