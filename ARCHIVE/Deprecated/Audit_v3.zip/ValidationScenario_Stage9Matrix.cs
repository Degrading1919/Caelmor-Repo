using System;
using System.Collections.Generic;
using Caelmor.Persistence;

namespace Caelmor.Systems
{
    public sealed class ValidationScenarioDeps
    {
        public readonly Action<int /*playerId*/, int /*nodeInstanceId*/> PerformValidGather;
        public readonly Action<int /*playerId*/, string /*recipeKey*/, string /*stationKey*/> PerformCraftAttempt;

        public readonly Action Setup_OnePlayerEmptyInventory;
        public readonly Action Setup_InventoryHasExactlyOneItem_ForCraft;
        public readonly Action Setup_NodeAvailable;
        public readonly Action Setup_NodeDepletedWithTicksRemaining;

        // Persistence snapshots MUST be per-player for multi-actor scenarios.
        public readonly Func<int /*playerId*/, PersistedPlayerSave> CapturePlayerSaveSnapshotFor;
        public readonly Func<PersistedWorldSave> CaptureWorldSaveSnapshot;

        public readonly int PlayerA;
        public readonly int PlayerB;
        public readonly int NodeId;
        public readonly string RecipeKey;
        public readonly string StationKey;

        public ValidationScenarioDeps(
            Action<int, int> performValidGather,
            Action<int, string, string> performCraftAttempt,
            Action setupOnePlayerEmptyInventory,
            Action setupInventoryHasExactlyOneItemForCraft,
            Action setupNodeAvailable,
            Action setupNodeDepletedWithTicksRemaining,
            Func<int, PersistedPlayerSave> capturePlayerSaveSnapshotFor,
            Func<PersistedWorldSave> captureWorldSaveSnapshot,
            int playerA,
            int playerB,
            int nodeId,
            string recipeKey,
            string stationKey)
        {
            PerformValidGather = performValidGather ?? throw new ArgumentNullException(nameof(performValidGather));
            PerformCraftAttempt = performCraftAttempt ?? throw new ArgumentNullException(nameof(performCraftAttempt));

            Setup_OnePlayerEmptyInventory = setupOnePlayerEmptyInventory ?? throw new ArgumentNullException(nameof(setupOnePlayerEmptyInventory));
            Setup_InventoryHasExactlyOneItem_ForCraft = setupInventoryHasExactlyOneItemForCraft ?? throw new ArgumentNullException(nameof(setupInventoryHasExactlyOneItemForCraft));
            Setup_NodeAvailable = setupNodeAvailable ?? throw new ArgumentNullException(nameof(setupNodeAvailable));
            Setup_NodeDepletedWithTicksRemaining = setupNodeDepletedWithTicksRemaining ?? throw new ArgumentNullException(nameof(setupNodeDepletedWithTicksRemaining));

            CapturePlayerSaveSnapshotFor = capturePlayerSaveSnapshotFor ?? throw new ArgumentNullException(nameof(capturePlayerSaveSnapshotFor));
            CaptureWorldSaveSnapshot = captureWorldSaveSnapshot ?? throw new ArgumentNullException(nameof(captureWorldSaveSnapshot));

            PlayerA = playerA;
            PlayerB = playerB;
            NodeId = nodeId;
            RecipeKey = recipeKey ?? throw new ArgumentNullException(nameof(recipeKey));
            StationKey = stationKey ?? throw new ArgumentNullException(nameof(stationKey));
        }
    }

    public static class ValidationScenario_Stage9Matrix
    {
        public static IReadOnlyList<IValidationScenario> BuildAll(ValidationScenarioDeps deps)
        {
            if (deps == null) throw new ArgumentNullException(nameof(deps));

            return new IValidationScenario[]
            {
                new Stage9Scenario_1_1_AtomicInventoryGrantPersistence(deps),
                new Stage9Scenario_1_2_DeterministicInventoryMutationOrdering(deps),

                new Stage9Scenario_2_1_NodeDepletionPersistenceAcrossSave(deps),
                new Stage9Scenario_2_2_NodeRespawnDeterminismAfterLoad(deps),

                new Stage9Scenario_3_1_CraftingCommitIntegrityOnDisconnect(deps),
                new Stage9Scenario_3_2_CraftingRejectionPersistence(deps),

                new Stage9Scenario_4_1_SimultaneousNodeInteractionResolution(deps),
                new Stage9Scenario_4_2_ContentionPersistenceAfterSave(deps),

                new Stage9Scenario_5_1_MidTickDisconnectSafety(deps),
                new Stage9Scenario_5_2_SessionResumeWithoutReplay(deps),

                new Stage9Scenario_6_1_CrossTickActionOrdering(deps),
                new Stage9Scenario_6_2_SaveRequestDuringActiveTick(deps),
            };
        }
    }

    internal abstract class Stage9ScenarioBase : IValidationScenario
    {
        protected readonly ValidationScenarioDeps Deps;

        protected int _phase;
        protected int _t0;

        protected Stage9ScenarioBase(ValidationScenarioDeps deps) => Deps = deps;

        public abstract string ScenarioId { get; }

        public virtual void Reset(IScenarioContext ctx)
        {
            _phase = 0;
            _t0 = -1;
        }

        protected void MarkT0(int tick)
        {
            if (_t0 < 0) _t0 = tick;
        }

        protected bool AtOrAfter(int tick, int dt) => tick >= (_t0 + dt);

        protected ScenarioStepResult Fail(string reason) => ScenarioStepResult.Failed(reason);
        protected ScenarioStepResult Pass() => ScenarioStepResult.Passed();
        protected ScenarioStepResult Run() => ScenarioStepResult.Running();

        protected static ValidationSnapshot_Inventory SnapshotInventoryFromSave(PersistedPlayerSave save)
        {
            var list = new List<ValidationInventoryEntry>(save.Inventory.Count);
            for (int i = 0; i < save.Inventory.Count; i++)
                list.Add(new ValidationInventoryEntry(save.Inventory[i].ResourceItemKey, save.Inventory[i].Count));

            list.Sort(static (a, b) => string.Compare(a.ResourceItemKey, b.ResourceItemKey, StringComparison.Ordinal));
            return new ValidationSnapshot_Inventory(save.PlayerId, list.ToArray());
        }
    }

    // -------------------------------------------------------------------------
    // 1. Inventory Determinism & Persistence (ALL assertions via PlayerSave only)
    // -------------------------------------------------------------------------

    internal sealed class Stage9Scenario_1_1_AtomicInventoryGrantPersistence : Stage9ScenarioBase
    {
        public Stage9Scenario_1_1_AtomicInventoryGrantPersistence(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "1.1_atomic_inventory_grant_persistence";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_empty_inventory", () => Deps.Setup_OnePlayerEmptyInventory());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("perform_valid_gather", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                _phase = 2;
                return Run();
            }

            if (_phase == 2 && AtOrAfter(tick, 2))
            {
                ctx.Save.RequestCheckpoint("scenario_1_1_post_gather");
                ctx.Save.CommitCheckpointIfRequested();

                // Assert only through persistence: PlayerSave after checkpoint.
                PersistedPlayerSave saved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                // Disconnect/reconnect modeled as hydration only.
                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedPlayerSave restored = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(saved),
                    SnapshotInventoryFromSave(restored),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    internal sealed class Stage9Scenario_1_2_DeterministicInventoryMutationOrdering : Stage9ScenarioBase
    {
        public Stage9Scenario_1_2_DeterministicInventoryMutationOrdering(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "1.2_deterministic_inventory_mutation_ordering";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_one_item_for_craft", () => Deps.Setup_InventoryHasExactlyOneItem_ForCraft());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                // Multiple crafting requests within the same tick (deterministic by enqueue order).
                ctx.EnqueueSerializedAction("craft_attempt_1", () => Deps.PerformCraftAttempt(Deps.PlayerA, Deps.RecipeKey, Deps.StationKey));
                ctx.EnqueueSerializedAction("craft_attempt_2", () => Deps.PerformCraftAttempt(Deps.PlayerA, Deps.RecipeKey, Deps.StationKey));
                ctx.EnqueueSerializedAction("craft_attempt_3", () => Deps.PerformCraftAttempt(Deps.PlayerA, Deps.RecipeKey, Deps.StationKey));

                ctx.Save.RequestCheckpoint("scenario_1_2_post_craft_burst");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedPlayerSave saved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedPlayerSave restored = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                // Deterministic ordering + no replay proven by identical post-commit state across restore.
                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(saved),
                    SnapshotInventoryFromSave(restored),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    // -------------------------------------------------------------------------
    // 2. Resource Node State & Respawn Persistence (WorldSave authority)
    // -------------------------------------------------------------------------

    internal sealed class Stage9Scenario_2_1_NodeDepletionPersistenceAcrossSave : Stage9ScenarioBase
    {
        public Stage9Scenario_2_1_NodeDepletionPersistenceAcrossSave(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "2.1_node_depletion_persistence_across_save";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_node_available", () => Deps.Setup_NodeAvailable());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("perform_valid_gather_deplete_node", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                _phase = 2;
                return Run();
            }

            if (_phase == 2 && AtOrAfter(tick, 2))
            {
                ctx.Save.RequestCheckpoint("scenario_2_1_post_deplete");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedWorldSave worldSaved = Deps.CaptureWorldSaveSnapshot();
                var snapSaved = ValidationSnapshotCapture.CaptureNodesFromWorldSave(worldSaved);

                ctx.Restore.RestoreWorldAndZone("test_zone");

                PersistedWorldSave worldRestored = Deps.CaptureWorldSaveSnapshot();
                var snapRestored = ValidationSnapshotCapture.CaptureNodesFromWorldSave(worldRestored);

                // WorldSave snapshots must match deterministically across restore.
                ValidationAssert.Equal(snapSaved, snapRestored, ScenarioId);
                return Pass();
            }

            return Run();
        }
    }

    internal sealed class Stage9Scenario_2_2_NodeRespawnDeterminismAfterLoad : Stage9ScenarioBase
    {
        public Stage9Scenario_2_2_NodeRespawnDeterminismAfterLoad(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "2.2_node_respawn_determinism_after_load";

        private int _ticksRemainingExpected = -1;

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_node_depleted_with_ticks_remaining", () => Deps.Setup_NodeDepletedWithTicksRemaining());

                ctx.Save.RequestCheckpoint("scenario_2_2_post_setup_depleted");
                ctx.Save.CommitCheckpointIfRequested();

                // Authoritative ticks_remaining is read from WorldSave only.
                PersistedWorldSave world = Deps.CaptureWorldSaveSnapshot();
                var nodes = ValidationSnapshotCapture.CaptureNodesFromWorldSave(world);
                int idx = nodes.IndexOf(Deps.NodeId);
                if (idx < 0) return Fail("missing_node_in_worldsave");

                var entry = nodes.Entries[idx];
                if (entry.Availability != ValidationNodeAvailability.Depleted) return Fail("node_not_depleted_after_setup");
                if (!entry.RespawnTicksRemaining.HasValue) return Fail("ticks_remaining_unknown_in_worldsave");

                _ticksRemainingExpected = entry.RespawnTicksRemaining.Value;

                // Restore hydration only.
                ctx.Restore.RestoreWorldAndZone("test_zone");
                _phase = 1;
                return Run();
            }

            // Runtime node query allowed ONLY for availability check (no ticks asserted via runtime).
            if (_phase == 1)
            {
                if (_ticksRemainingExpected < 0) return Fail("invalid_expected_ticks_remaining");

                int dt = tick - _t0;
                if (dt < _ticksRemainingExpected)
                {
                    var nodeSnap = ctx.State.CaptureNode(Deps.NodeId);
                    if (!nodeSnap.Exists) return Fail("node_missing_runtime");
                    if (nodeSnap.Available) return Fail("early_respawn");
                    return Run();
                }

                var nodeSnapAfter = ctx.State.CaptureNode(Deps.NodeId);
                if (!nodeSnapAfter.Exists) return Fail("node_missing_runtime_after");
                if (!nodeSnapAfter.Available) return Fail("delayed_respawn");

                _phase = 2;
                return Run();
            }

            if (_phase == 2)
            {
                var nodeSnapNext = ctx.State.CaptureNode(Deps.NodeId);
                if (!nodeSnapNext.Exists) return Fail("node_missing_runtime_next_tick");
                if (!nodeSnapNext.Available) return Fail("respawn_flapped");
                return Pass();
            }

            return Run();
        }
    }

    // -------------------------------------------------------------------------
    // 3. Crafting Atomicity Across Save/Load (PlayerSave authority)
    // -------------------------------------------------------------------------

    internal sealed class Stage9Scenario_3_1_CraftingCommitIntegrityOnDisconnect : Stage9ScenarioBase
    {
        public Stage9Scenario_3_1_CraftingCommitIntegrityOnDisconnect(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "3.1_crafting_commit_integrity_on_disconnect";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_one_item_for_craft", () => Deps.Setup_InventoryHasExactlyOneItem_ForCraft());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("craft_attempt", () => Deps.PerformCraftAttempt(Deps.PlayerA, Deps.RecipeKey, Deps.StationKey));

                ctx.Save.RequestCheckpoint("scenario_3_1_post_craft");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedPlayerSave saved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedPlayerSave restored = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(saved),
                    SnapshotInventoryFromSave(restored),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    internal sealed class Stage9Scenario_3_2_CraftingRejectionPersistence : Stage9ScenarioBase
    {
        public Stage9Scenario_3_2_CraftingRejectionPersistence(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "3.2_crafting_rejection_persistence";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_empty_inventory", () => Deps.Setup_OnePlayerEmptyInventory());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("craft_attempt_rejected", () => Deps.PerformCraftAttempt(Deps.PlayerA, Deps.RecipeKey, Deps.StationKey));

                ctx.Save.RequestCheckpoint("scenario_3_2_post_reject");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedPlayerSave saved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedPlayerSave restored = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(saved),
                    SnapshotInventoryFromSave(restored),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    // -------------------------------------------------------------------------
    // 4. Multi-Actor Resource Contention
    // -------------------------------------------------------------------------

    internal sealed class Stage9Scenario_4_1_SimultaneousNodeInteractionResolution : Stage9ScenarioBase
    {
        public Stage9Scenario_4_1_SimultaneousNodeInteractionResolution(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "4.1_simultaneous_node_interaction_resolution";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_node_available", () => Deps.Setup_NodeAvailable());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("gather_A", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                ctx.EnqueueSerializedAction("gather_B", () => Deps.PerformValidGather(Deps.PlayerB, Deps.NodeId));

                ctx.Save.RequestCheckpoint("scenario_4_1_post_contention");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedWorldSave worldSaved = Deps.CaptureWorldSaveSnapshot();
                var snapSaved = ValidationSnapshotCapture.CaptureNodesFromWorldSave(worldSaved);

                ctx.Restore.RestoreWorldAndZone("test_zone");

                PersistedWorldSave worldRestored = Deps.CaptureWorldSaveSnapshot();
                var snapRestored = ValidationSnapshotCapture.CaptureNodesFromWorldSave(worldRestored);

                ValidationAssert.Equal(snapSaved, snapRestored, ScenarioId);
                return Pass();
            }

            return Run();
        }
    }

    internal sealed class Stage9Scenario_4_2_ContentionPersistenceAfterSave : Stage9ScenarioBase
    {
        public Stage9Scenario_4_2_ContentionPersistenceAfterSave(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "4.2_contention_persistence_after_save";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_node_available", () => Deps.Setup_NodeAvailable());
                ctx.EnqueueSerializedAction("setup_empty_inventory_A", () => Deps.Setup_OnePlayerEmptyInventory());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("gather_A", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                ctx.EnqueueSerializedAction("gather_B_rejected", () => Deps.PerformValidGather(Deps.PlayerB, Deps.NodeId));

                ctx.Save.RequestCheckpoint("scenario_4_2_post_contention_save");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedPlayerSave savedB = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerB);

                ctx.Restore.RestorePlayerInventory(Deps.PlayerB);

                PersistedPlayerSave restoredB = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerB);

                // Player B must not receive retroactive grants on reconnect.
                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(savedB),
                    SnapshotInventoryFromSave(restoredB),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    // -------------------------------------------------------------------------
    // 5. Reconnect & Session Boundary Integrity (PlayerSave authority)
    // -------------------------------------------------------------------------

    internal sealed class Stage9Scenario_5_1_MidTickDisconnectSafety : Stage9ScenarioBase
    {
        public Stage9Scenario_5_1_MidTickDisconnectSafety(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "5.1_mid_tick_disconnect_safety";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_empty_inventory", () => Deps.Setup_OnePlayerEmptyInventory());
                ctx.EnqueueSerializedAction("setup_node_available", () => Deps.Setup_NodeAvailable());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("gather_attempt", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                _phase = 2;
                return Run();
            }

            if (_phase == 2 && AtOrAfter(tick, 2))
            {
                ctx.Save.RequestCheckpoint("scenario_5_1_post_tick_resolution");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedPlayerSave saved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedPlayerSave restored = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(saved),
                    SnapshotInventoryFromSave(restored),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    internal sealed class Stage9Scenario_5_2_SessionResumeWithoutReplay : Stage9ScenarioBase
    {
        public Stage9Scenario_5_2_SessionResumeWithoutReplay(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "5.2_session_resume_without_replay";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_empty_inventory", () => Deps.Setup_OnePlayerEmptyInventory());
                ctx.EnqueueSerializedAction("setup_node_available", () => Deps.Setup_NodeAvailable());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("gather_1", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                ctx.EnqueueSerializedAction("craft_attempt", () => Deps.PerformCraftAttempt(Deps.PlayerA, Deps.RecipeKey, Deps.StationKey));

                ctx.Save.RequestCheckpoint("scenario_5_2_post_actions");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedPlayerSave saved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedPlayerSave restored = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(saved),
                    SnapshotInventoryFromSave(restored),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    // -------------------------------------------------------------------------
    // 6. Tick-Boundary Edge Conditions
    // -------------------------------------------------------------------------

    internal sealed class Stage9Scenario_6_1_CrossTickActionOrdering : Stage9ScenarioBase
    {
        public Stage9Scenario_6_1_CrossTickActionOrdering(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "6.1_cross_tick_action_ordering";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_empty_inventory", () => Deps.Setup_OnePlayerEmptyInventory());
                ctx.EnqueueSerializedAction("setup_node_available", () => Deps.Setup_NodeAvailable());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                ctx.EnqueueSerializedAction("action_A_gather", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                _phase = 2;
                return Run();
            }

            if (_phase == 2 && AtOrAfter(tick, 2))
            {
                ctx.EnqueueSerializedAction("action_B_craft", () => Deps.PerformCraftAttempt(Deps.PlayerA, Deps.RecipeKey, Deps.StationKey));

                ctx.Save.RequestCheckpoint("scenario_6_1_post_actions");
                ctx.Save.CommitCheckpointIfRequested();

                PersistedPlayerSave saved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedPlayerSave restored = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(saved),
                    SnapshotInventoryFromSave(restored),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }

    internal sealed class Stage9Scenario_6_2_SaveRequestDuringActiveTick : Stage9ScenarioBase
    {
        public Stage9Scenario_6_2_SaveRequestDuringActiveTick(ValidationScenarioDeps deps) : base(deps) { }
        public override string ScenarioId => "6.2_save_request_during_active_tick";

        public override ScenarioStepResult OnTick(IScenarioContext ctx, int tick)
        {
            MarkT0(tick);

            if (_phase == 0)
            {
                ctx.EnqueueSerializedAction("setup_empty_inventory", () => Deps.Setup_OnePlayerEmptyInventory());
                ctx.EnqueueSerializedAction("setup_node_available", () => Deps.Setup_NodeAvailable());
                _phase = 1;
                return Run();
            }

            if (_phase == 1 && AtOrAfter(tick, 1))
            {
                // Save requested during active tick; must not commit mid-tick.
                ctx.Save.RequestCheckpoint("scenario_6_2_requested_mid_tick");

                ctx.EnqueueSerializedAction("gather_action_pending", () => Deps.PerformValidGather(Deps.PlayerA, Deps.NodeId));
                _phase = 2;
                return Run();
            }

            if (_phase == 2 && AtOrAfter(tick, 2))
            {
                ctx.Save.CommitCheckpointIfRequested();

                PersistedWorldSave worldSaved = Deps.CaptureWorldSaveSnapshot();
                PersistedPlayerSave playerSaved = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ctx.Restore.RestoreWorldAndZone("test_zone");
                ctx.Restore.RestorePlayerInventory(Deps.PlayerA);

                PersistedWorldSave worldAfter = Deps.CaptureWorldSaveSnapshot();
                PersistedPlayerSave playerAfter = Deps.CapturePlayerSaveSnapshotFor(Deps.PlayerA);

                ValidationAssert.Equal(
                    ValidationSnapshotCapture.CaptureNodesFromWorldSave(worldSaved),
                    ValidationSnapshotCapture.CaptureNodesFromWorldSave(worldAfter),
                    ScenarioId);

                ValidationAssert.Equal(
                    SnapshotInventoryFromSave(playerSaved),
                    SnapshotInventoryFromSave(playerAfter),
                    ScenarioId);

                return Pass();
            }

            return Run();
        }
    }
}
