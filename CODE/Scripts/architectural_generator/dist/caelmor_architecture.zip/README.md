# Caelmor Architectural Generator

Version 0.22.0 is an offline Blender add-on for editable, metre-scale buildings. It combines twenty building types, regional working grammars, an optional world-aware construction language, manual orthogonal massing, procedural facades and roofs, original material maps, and semantic export metadata. An isolated, opt-in Unity client floor-presentation adapter accompanies floor-aware exports; it is not wired into the playable scene.

## Start here

Open **3D View → Sidebar → Caelmor** and choose **Create Building**. Pick the type and a starting style. **Recommended** sizes it for you, **Enter Dimensions** sets the main volume, and **Selected Box** fits the main envelope to an upright rectangular mesh you place and rotate in Object Mode. The box remains editable. Forge and gate passage layouts size their own working bays. Market halls and stables require room for their circulation and service bays.

Select part of a building to edit it. **Shape** changes its dimensions, or refits the source box. **Roof** edits the selected volume. Gable, hip, pitch, and overhang choices keep the building's regional construction. **Assign Material** applies a scene material immediately when confirmed. Use the selected part, the corresponding construction group, or **Restore Default Material**. **Construction** exposes assembly choices relevant to the selection. **Condition** changes age, maintenance, and workmanship. Enable **Protect Mesh Edits** on an object before hand-modeling it.

For a box-fitted Lowmark Cottage, select a guide face or edge and choose **Add Wall Feature**. An attached guide shows actions to change its type, update its shape or location, or remove it. Select a generated opening and use **Select Feature Guide** to return to its source.

Use **Roof from Walls** in the same sidebar for standalone roofs on manually built walls. Preview the wall top, choose material and roof height, and generate. Select a previously generated standalone roof to edit its settings.

**Advanced Tools** contains seeds, mesh fidelity, material height, floor preview, diagnostics, and export. Use **Load Building into Draft** before changing expert controls, then **Apply Draft**. The routine **Regenerate** action rebuilds the selected building from its saved choices. If a roof or dimension edit conflicts with an adjacent assembly or a protected part, the last valid building stays in place.

New buildings have floor-separated visuals by default. Select a building, set
**Simulated floor** (0 = ground, −1 = exterior), choose its **Construction volume**
and **Apply Floor Preview**. The preview only hides visual components. Full GLB
exports remain complete even while previewing an interior. Old saved buildings
remain unsplit until explicitly enabled and regenerated; unprotect edited
sections before changing representation. See [floor evidence and integration
handoff](evidence/floor_visibility/README.md) for limitations and measurements.

See the [engine contract](ENGINE_CONTRACT.md) for the current source baseline, legacy scene compatibility and the proposed treatment interface.

The 0.12.2 pigment study adds directional color to selected Lowmark Smithy
timbers and mineral color accents to the Thornfell Gatehouse's existing
masonry faces and bevels. See [the study](evidence/painted_materials) for the
matched views and GLB checks.

The 0.12.1 Thornfell Gatehouse finish groups warmer and cooler stock across
neighboring wall stones. It preserves the separate dressed stone and the
existing material maps and geometry workflow. See the
[reference study and comparison](evidence/masonry_stock).

In 0.12, **Seed Changes Layout** varies construction in the world-aware
Lowmark Smithy and Thornfell Gatehouse. It is on in new Blender scenes.
Older building snapshots load with the option off. Use full regeneration
to change the seed layout of an existing building, since structure, roofs,
routes and collision proxies are sized together. See
[five-seed comparisons](evidence/diversity_v12) for the verified range.

The 0.11 **Crafted Curves** control is on for new Blender scenes in world-aware mode.
It adds swept gables and fitted timber to the Lowmark Smithy, a taller splayed
portal to the Thornfell Gatehouse, and continuous roof ribs where Mire builders
use bowed roofs. Turn it off to use straight Smithy joinery and the earlier
Gatehouse portal profile. Older building
snapshots load with the option off. Change the option with full regeneration
so roof, structure and aperture geometry are rebuilt together. See
[evidence/curves_v11](evidence/curves_v11) for matched comparisons and checks.

The 0.10 art pass gives the Lowmark Smithy heavier timber bents and hewn knees. The Thornfell Gatehouse gains worked stone faces, bonded battered plinths and ground-bearing flagstone approaches. Both use stronger regional material contrasts. Compact condition atlases and shared metric normal tiles preserve the finish in GLB. See `evidence/polish_v10` for comparisons and checks.

The 0.9 surface pass preserves the 0.8 procedural geometry. Standard exported
PBR maps now carry preparation, material sorting and environmental history.
Wealth sorts natural stock; craftsmanship controls preparation/tool marks and
finish; age accumulates patina; maintenance reduces deterioration and supplies
localized replacements, repointing and limewash. Wealth does not set cleanliness.
The Lowmark Smithy and Thornfell Gatehouse are the controlled visual fixtures;
see `evidence/materials_v09` for surface-only comparisons and actual GLB
round-trip diagnostics. These isolate finishes on identical geometry; normal
generation continues to honor wealth/craftsmanship's existing construction rules.

Surface maps are original packed albedo, tangent-normal and ORM PNGs connected
directly to Principled BSDF, with no renderer-only procedural shader dependency.
`UV2_Surface` supplements `UV0_Metric` and `UV1_Lightmap`; mesh vertices/faces
are unchanged. CaelmorTint is neutral for these baked materials to avoid double
weathering on export. Detail controls map density (wood receives twice the base
density); individual face charts are capped at 256 pixels and atlases at 4096
per dimension. This is an authoring resolution policy, not a runtime budget.
Blender's bundled NumPy evaluates the maps; no external textures or packages are
downloaded. Atlas revision 1 is separate from the retained legacy surface bank.
Unchanged geometry/settings reuse their material datablocks, preserving shader
edits. Explicit material-slot overrides and protected objects survive regeneration.
Changing condition inputs creates a new finish bank instead of overwriting a
material an artist may have edited. Old manually edited surfaces can remain on
protected objects; condition changes do not forcibly replace them.

The 0.8 art benchmarks revise **Lowmark Smithy** and **Thornfell Gatehouse** in
World mode. The smithy has a primary gabled forge and a lower boarded stock
range, with fire screening, coursed stack, pegged bents and repair equipment.
The gatehouse has broad hipped flanks, an actual vaulted archway, courtyard
entries, defensive slots and a guard hall. These are procedural construction
rules for every seed of the selected pair, with fixed-camera before/after
comparisons under `evidence/benchmarks_v08`. Artistic acceptance is pending;
the other 78 region/function combinations retain their existing geometry.

In World mode, Smithy, Market Hall, Stable and Gatehouse now allocate functional
spaces before their regional construction shell. Integral work equipment,
trading bays, animal stalls and guarding/access arrangements are limited to
those programs; this is not a general interior generator. Program rooms,
stations, clearances and approaches are included in the export sidecar. Other
functions retain their existing regional builders, and legacy/manual mode
remains available. See [FUNCTIONAL_PROGRAMS.md](FUNCTIONAL_PROGRAMS.md) for the
construction contract, inference boundaries and small visual acceptance set.

The 0.7 construction pass gives these programs shaped working equipment,
framed selling bays and open hall trusses, constructed stall gates and feeding
troughs, and deep defended portals with masonry arches and battered tower
buttresses. Lowmark and Thornfell market ridges now follow the public aisle;
Mire keeps its raised crowned shelter and Emberholt its mineral terrace.
Sloping wall infill is cut across its full thickness beneath the roof. These
are geometry changes, with the existing studio and material system retained
for comparison; they remain subject to Creative Director artistic acceptance.

The regional mappings and exact architectural choices are reversible visual interpretations of the four regional dossiers, not new canon. See [REGIONAL_GRAMMAR.md](REGIONAL_GRAMMAR.md) for the source cues, context IDs, type grammar, and boundaries of those interpretations. [WORLD_ARCHITECTURAL_LANGUAGES.md](WORLD_ARCHITECTURAL_LANGUAGES.md) records the broader structural art direction; its proposals are visual interpretations, not canon or approved material catalogs.

The 0.5 household pass makes investment change usable construction: Lowmark
work/store/private-room compounds; calm Thornfell domestic roofs and sheltered
room ranges; Mire compact landings versus roofed work decks/private links; and
Emberholt hearth halls, narrow artisan bodies, lower work ranges and private
courts. Craftsmanship and condition remain separate controls. Emberholt work
roofs use lapped iron sheets, household windows have enclosed domestic
proportions, and soot follows generated hearths. See
[ARTISTIC_REFINEMENT.md](ARTISTIC_REFINEMENT.md) for the matched comparison brief,
research and limits. These are reviewable art improvements, not production-art
approval.

## Requirements and installation

- Blender 5.0.1 is the tested target. The extension manifest declares Blender 4.2 as its minimum; other Blender releases have not been validated.
- Install `dist/caelmor_architecture.zip` using **Edit → Preferences → Get Extensions → Install from Disk**, then enable **Caelmor Architectural Generator**.
- Open a 3D View and find the **Caelmor** tab in the N-panel.
- Rebuild the distributable with `py -3 package_addon.py` from this directory. The ZIP contains the add-on source, full GPL license, third-party notices, research reference, architecture references and household comparison brief.

## Artist-directed Lowmark Cottage

1. In a metre-scale scene, place a plain cube and scale it into a rectangular
   building proxy in Object Mode. Local **−Y** faces the entrance. The bottom
   sets the foundation datum and the top sets the eaves, with the gabled roof
   extending above and beyond the box. Use an upright, unmodified box with a
   6–24 m width and 4–16 m depth. For one floor, use a 2.85–4.25 m box height.
2. With the box selected, choose **Create Building** and select **Lowmark / Cottage**,
   **Selected Box**, and the desired storey count. The Lowmark core fits the box
   exactly. Set the separate source to Wire display and hide it from renders as needed.
3. Use **Construction** to change the assembly or the selected timber profile.
   **Assign Material** changes the part or matching group when you confirm it.
   A selected construction component can also store a rotation of the generated
   `UV0_Metric`. **Restore Default Material** removes the chosen assignment.
   A component can cover several meshes or floor sections.
4. If you move, rotate or resize the box, select the generated cottage and
   use **Refit Box**. An ordinary regeneration uses the last fitted dimensions.
   Protected manual sections move with the anchor. A refit that changes their
   generated source geometry reports the conflict before replacing any meshes.
5. Use **Advanced Tools → Export Building** for the visual GLB, separate
   collision GLB and metadata. The source box is excluded. Substance-produced
   Blender materials use the same picker as other loaded materials. Keep
   material names stable across regeneration, and use exportable PBR image
   inputs on Principled BSDF for Unity. Materials using custom procedural shader
   graphs may need baking or conversion first. Rotation affects materials
   that sample `UV0_Metric` or the active UVs. Existing manually replaced
   material slots and protected meshes still take precedence.

The fit workflow currently handles the Lowmark Cottage's single main volume.
Use separate authored blockouts for other scene elements. Roof AutoComplete
retains its existing entry point. The Geometry controls set authoring fidelity;
material reuse, render submissions, compression and collision also affect
runtime cost. See the [executed Unity benchmark](evidence/lowmark_settlement/PERFORMANCE.md)
and the [Cottage authoring verification](evidence/blockout_authoring/README.md).

## Feature Guides

1. Fit a **Lowmark Cottage** using the workflow above. In the **Feature
   Guides** panel the new cottage becomes the target. Use **Target Cottage**
   when working on another unbound face.
2. Make one upright mesh face parallel to a wall in Object Mode, within 0.22 m
   of the exterior wall plane. For a door, put its bottom at the top of the
   plinth (0.45 m above the bottom of the cottage box). Use a rectangle for
   **Door** or **Window**. **Rounded Door** accepts that same rectangle with a
   default shallow head, or a convex face with a level threshold, vertical
   jambs and a symmetric elliptical head. Door heads need to clear the wall
   plate and neighboring openings. Out-of-range guides receive a diagnosis.
3. Select the face, choose **Add Wall Feature**, and confirm the type. It stays editable and
   appears as a wire guide parented to the building root. It is excluded from
   renders and the GLB. The generated assembly has stable component IDs for
   material assignment and a separate collision representation. Clear **Include Closed Door**
   to create an open passage and an approach collider. A closed leaf or a
   glazed window keeps static wall collision.
4. Move the guide along its wall or edit its vertices. Select the guide or a
   generated part of the cottage and use **Update Feature** or **Update Wall Features**. To move a guide
   to a different wall, reapply it through **Change Feature Type**. Use **Remove**
   to detach it and restore the wall, or delete the source and regenerate. It
   remembers its ID, host wall and options through save/reopen. Refit preserves
   distances measured from each host wall's start corner.

Guided edits retain unchanged visual objects, including their direct material
slot edits. Guides can replace intersecting **automatic windows**. They fail
if they overlap the main entrance, another guide or a protected section that
must be rebuilt. Protect hand-edited generated wall and frame sections before
regenerating. The current workflow covers rectangular windows and straight or
rounded ground-floor doors on the four walls of a fitted Lowmark Cottage.
See the [editable opening examples](evidence/opening_guides/README.md).

**Timber Post** uses one vertical mesh edge from the plinth to the roof plate.
Place it against a timber-framed wall. The tool sizes the post using the host
frame and recalculates the bays, default post stations and braces around it.
Leave room for existing openings, corner posts and other guided posts.

**Plaster Loss** uses one irregular face on a rendered timber infill panel.
Keep a single outline with a visible center and clear the framing, openings
and adjacent loss. The tool cuts the render layer and exposes recessed earthen
infill. Move, edit and remove either source using the same guide controls.
See the [wall feature examples and tests](evidence/wall_feature_guides/README.md).

In Unity, export and reimport to the same path and key for compatible guide
edits. The importer reconciles stable guide parts and holds the generated and
placement prefab identities. Removing a section with an authored reference
or override reports the scene or asset that needs review. Changes to building
identity, floor layout or core construction structure remain guarded.

## Roof AutoComplete

Install or update the extension with the ZIP above. In Blender 5.0, open a
scene where one Blender unit represents one metre and select the exterior
wall modules in Object Mode. Include the structural wall core on each side.
Open **N → Caelmor → Roof from Walls** and choose **Preview Wall Top**.
The outline shows the wall centre lines and bearing elevation. To correct it,
open **Advanced**, edit the bearing centre, width, depth or angle, then choose
**Preview Manual Bearing**.

Choose **Brookoak Shingles** and set **Roof Height** to the structural ridge
rise above the bearing. Rise determines pitch for the selected span. Advanced
controls set the ridge axis and seed. Set overhang with the other roof controls. The PBR map folder defaults to
the designated checkout's `MEDIA/Materials/procedurally_generated` directory.
The material uses the Brookoak albedo PNG, normal PNG and roughness EXR.

**Generate / Update Roof** confirms the displayed bearing and creates an
editable roof collection. To revisit a roof, choose its collection in
**Existing Roof** or select the roof and choose **Edit Selected Roof**. Updating replaces the tool's
generated parts in that collection. Duplicate any manually edited parts you
want to keep across regeneration into another collection. **Export Roof GLB**
exports the generated parts of the target.

Geometry Detail is the approximate share of shingle cells modeled on each
slope. At 0%, one continuous textured field covers each slope. At 100%, the
visible covering is all dimensional shingles. Intermediate values add
boards across each slope in a seeded order that preserves prior choices.
The panel shows modeled board and triangle counts. The percentage measures
board count. Triangle count depends on clipping and shared edges.

The deck, fascia, rafters, ridge caps and gable infill remain at every
setting. Course exposure is 0.30 m up the slope. U runs along the eave with
a 1.28 m repeat, and V covers eight courses per repeat. The tool uses
measured side joints from the approved Brookoak albedo to map the same
albedo, normal and roughness to flat and dimensional boards. A modeled
board replaces its flat area and tapers into the field at the head.
Fine painted joint wander can differ from the straight modeled edge.
Point the tool at the approved export set. A different albedo requires a
new course layout. The Material Maker source retains its existing controls.

The tool fits a level rectangle or a supported orthogonal outline formed by
a main rectangle and one perpendicular wing. Select the wall cores and
check the proposed outline before generating. The advanced bearing controls
translate, rotate or proportionally resize the inferred layout. Compound
roof height sets the main ridge rise and both volumes use the same pitch.
The preset accepts 15–65° main pitches. A diagonal wall gets a diagnostic
with object names and approximate angular offsets so it can be located in
the scene. Existing saved rectangular roofs can be loaded and updated onto
the new detail behavior.

[Native fixture and evidence](evidence/roof_autocomplete/)

## Generate a building

**Create Building** starts from a function, style, and sizing method. It stores the settings and validation summary on the resulting building collection. **Condition** and **Advanced Tools** expose further choices when needed.

### Regions and contexts

The region selector offers Lowmark Vale, Thornfell Marches, Mire of Fallen Banners, and Emberholt Heights. The local-context menu is limited to stable IDs for the selected region; **Regional Default** uses that region's default context. Context shifts affect grammar-mode massing and the resolved regional style. Regional palette and construction choices stay grounded in ordinary local stone, timber, plaster, and roof materials; hidden ancient cultures and magical motifs are not applied as general neighborhood decoration.

### Twenty building types

The twenty parametric archetypes cover these broad uses:

- **Residential:** Farmhouse, Cottage, Townhouse, Longhouse.
- **Agricultural:** Barn, Grain Store, Stable.
- **Commercial:** Miller, Inn, Merchant House, Shop, Warehouse, Market Hall.
- **Industrial and craft:** Smithy, Workshop.
- **Civic:** Assembly Hall.
- **Defensive:** Watchtower, Gatehouse, Barracks.
- **Waterfront:** Boathouse.

Each type has its own default plan proportions and exterior features such as stalls, loading openings, forge stacks, public porches, watch galleries, gate passages, or waterside access. These are parametric exterior forms, not prefab meshes.

### Grammar and manual shape

Recommended sizing uses building type, region, context, investment, and workmanship. **Shape** can set the main volume directly while secondary volumes retain their regional arrangement. **Roof** stores choices by volume. Choose **Recommended** in the roof dialog and clear its pitch and overhang overrides to return to that volume's suggested form.

The advanced single-plan option retains older manual and grammar workflows. Its **Shape** dialog also exposes the legacy footprint and wing dimensions.

The supported footprints are RECT, L, T, and U. L wings may mirror, T wings may shift, and U wings may have unequal depths according to the seed. The guardrails require width 6–24 m, depth 4–16 m, 1–3 floors, and wing widths of at least 2.5 m. Non-rectangular wings must fit the main body, and U footprints retain at least 2 m of courtyard clearance.

### Household finish and condition

Wealth (Modest, Established, Affluent) changes household capacity, work/storage space and private-room/access arrangements in World mode, as well as grammar-mode scale and local finish assumptions. Craftsmanship (Rough, Standard, Fine) affects proportions, masonry selection, joinery and surface finish. Age and Maintenance are separate inputs: older maintained buildings retain patina and repair history, while neglected buildings accumulate exposure-specific deterioration. Wealth does not determine upkeep. These are authoring controls, not economic simulation or canonical social classes. The legacy material revision 4 bank remains readable; the current atlas bank uses separate fingerprints and datablocks. Saved settings remain readable; exact older World output and finishes require their original version. Protected pieces remain intact and can require manual reconciliation with a changed room arrangement.

### Detail and geometry modes

**High**, **Medium**, and **Low** alter architectural detailing and roof-course density. They do not represent runtime quality settings.

- **Solid** is the default, with a closed roof deck and closed structural components.
- **Efficient** reduces hidden roof layering and headlap geometry, and uses surface topology for physical cladding skins. The closed roof deck and structural core remain; exposed shingle relief, selected roof bedding, and optimized construction skins are tagged as `SURFACE` and are intentionally open surface geometry. This trades fully solid decorative layers for lower geometry counts; it is not a fully watertight building mesh.

The add-on reports effective plan dimensions and the latest geometry validation result in the panel.

## Construction library

Choose the building and region first, then expand **Construction library**.
The regional default follows local practice for every component. Use the
individual selectors to choose stone foundation bonding, structural supports,
masonry wall bodies or framed infill, roof structure and roof covering.
The household section still controls craftsmanship, wealth, age and maintenance
independently. Choose an artist material under **Set a finish on this role**.
An empty material explicitly restores the procedural finish for that role.

The library currently offers broken-course, level-coursed and dressed stone,
hewn and pegged or squared and housed timber, boarded or rendered infill, and
split shingles, slate or fired-clay roofing. Some function-specific assemblies
retain their dedicated builders. A selection that targets no compatible role,
such as a mineral cover override on a specialized reed-only roof, is rejected
with the relevant role or component. Existing per-component overrides take
precedence over the building-wide controls and are preserved on load.

New Blender scenes enable construction treatments. Older collections with no
construction overrides load with the switch off. Python callers can omit
`construction_overrides` for the legacy path, pass `{}` for role-based
defaults, or supply a JSON-compatible override map:

```json
{
  "by_role": {
    "frame_member": {"treatment": "structural_timber", "variant": "hewn_pegged"},
    "roof_cover": {"treatment": "slate_tile_roofing", "substrate": "fired_clay"}
  },
  "by_component": {"forge_hall/roof_cover": {"substrate": "slate"}}
}
```

Inspect a mesh's `caelm_component_id` for its exact key. Overrides inherit
field by field. A finish can be `procedural` or
`material:<existing Blender material name>`. Named materials should use the
metric UV set for mapped export. Manually replaced material slots take
priority. Changing the assembly choices requires regeneration of all layers.
The collection lists retained protected pieces that differ from the new plan.

Enable **Construction Metadata** in the export dialog to include optional
provenance and overrides in the format-1 sidecar. The default keeps the legacy
field set. See the [engine contract](ENGINE_CONTRACT.md) and
[vertical-slice comparisons](evidence/construction_library/README.md).

### Construction depth study

With **Efficient** geometry, the Construction library can opt a roof cover or
exposed masonry wall into **Hybrid** or **Texture dominant** depth. **Modeled**
remains the default. Hybrid keeps physical perimeter units and structural
accents over a shared mapped field. Texture dominant retains the essential
terminations and relies more heavily on the field. See the
[measured Smithy and Gatehouse comparisons](evidence/construction_depth/README.md)
before choosing either alternative for a production asset.

Slate, fired clay and split wood use separate relief profiles. An artist
finish can replace the shared procedural maps, and the mapped field inherits
an existing manual replacement from its primary modeled skin. A protected
surface blocks a representation change that would otherwise layer a new
field over the retained edit. Keep its current depth setting or reconcile the
edited surface before regenerating with another representation.

## Regeneration and export

**Regenerate** uses the selected building's saved settings. Use **Advanced Tools** for scoped refreshes and export. **Protect Mesh Edits** retains the selected mesh through compatible regeneration and includes it in exports.

Exports write GLB or glTF, a separate approximate collision GLB when proxies exist, and a `.caelmor.json` sidecar. The sidecar records settings, architecture mode, construction-zone bounds and validation counts, geometry hash, semantic layers, each object's world-zone, material and topology, structural role, roof-envelope/support-surface diagnostics, and protected state. World-aware collision proxies are generated for each construction zone and use its own foundation and eave heights; legacy proxies retain their prior layout. Collision proxies are approximate static wall and footprint shapes; they have not been tested for traversal or in Unity.

Generated meshes include metric UV0, packed UV1 lightmap coordinates, material factors, and normalized `COLOR_0` weathering. Original tileable 128×128 color, tangent-normal, and roughness maps are generated for shared wood, stone, plaster, and roof material families and packed into the Blender file. Region/context/wealth/craftsmanship palettes are cached independently of seed; small seed variation is baked per building. GLB embeds supported material images. Review material behavior in the target pipeline before production use.

## Python API

With Blender's Python environment and the add-on on `sys.path`:

```python
from caelmor_architecture.model import Settings, make_plan, resolve_settings
from caelmor_architecture.engine import generate, validate
from caelmor_architecture.blender_backend import build, export_building

settings = Settings(
    seed=17, function="BOATHOUSE", region="MIRE", context="SORROWMERE",
    use_grammar=True, wealth="ESTABLISHED", craftsmanship="STANDARD",
    geometry_mode="SOLID", world_aware=True,
)
effective = resolve_settings(settings)
plan, buffers = generate(settings)
report = validate(plan, buffers)
collection, metrics = build(settings)
sidecar_path = export_building(collection, r"C:\temp\boathouse.glb")
```

`generate` and `validate` are pure Python. `build` creates or replaces Blender objects; `export_building` writes the interchange files. The `Settings` API defaults `world_aware=False` so existing scripts keep the legacy path; new Blender UI settings default it on. Snapshots without `world_aware` load with it off, preserving the prior geometry path and manual settings. Snapshots without the other regional additions continue to load as manual Lowmark SOLID buildings with a Gable roof.

## Development checks

Use Python 3.11+ (or Blender's bundled Python) for pure geometry checks and Blender 5.0.1 for scene and export integration:

```powershell
py -3 -m unittest discover -s tests -p "test_generator.py" -v
py -3 -m unittest discover -s tests -p "test_geometry.py" -v
py -3 -m unittest discover -s tests -p "test_expansion.py" -v
py -3 -m unittest discover -s tests -p "test_facade_raycast.py" -v
py -3 tests/test_world.py
py -3 tests/stress_world.py
py -3 tests/measure_geometry_modes.py --world
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --factory-startup --background --python tests/test_world_blender.py
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --factory-startup --background --python tests/render_world_evidence.py -- --matrix
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --factory-startup --background --python tests/render_world_feature_heroes.py
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --background --python tests/test_blender.py
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --background --python tests/test_roof_clearance.py
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --background --python tests/test_glass_timber_bvh.py
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --background --python tests/test_profiles_blender.py
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --background --python tests/smoke_surface_export.py
& "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe" --background --python tests/render_expansion_evidence.py
./tests/compose_expansion_evidence.ps1
py -3 verify_install.py
```

See [tests/V05_VALIDATION.md](tests/V05_VALIDATION.md) for current household verification, [tests/WORLD_VALIDATION.md](tests/WORLD_VALIDATION.md) for the retained v0.4 record and [tests/VALIDATION.md](tests/VALIDATION.md) for v0.3/v0.2. Validation is generator and Blender authoring evidence, not target-engine compatibility or player experience.

## Scope limits

This is an exterior generator for orthogonal RECT/L/T/U footprints. It does not create arbitrary drawn polygons, interiors, enterable room layouts, or a complete settlement. Weathering, materials, and condition are procedural art, not measured simulation. Exported material behavior, collision, lighting, traversal, and performance still need review in any target engine.

World construction derives mass placement and roof shapes from the region; unused legacy footprint/wing/pitch/eave controls are disabled. Shared opening details, repeated surface patterns and some broad masonry faces still need artistic refinement. Protected manual edits remain intact but are outside the procedural geometry checks; changing a building's architectural language can require manual reconciliation of those edits. No interior load analysis or terrain fitting is claimed.

## License and original assets

The add-on source is GPL-3.0-or-later; the complete license is included as `caelmor_architecture/LICENSE`. Redistributing or modifying the add-on source requires following the GPL terms and preserving the applicable notices. Procedural material maps and generated geometry are original project assets created by this tool; no downloaded textures, prefab library, or third-party mesh assets are included. Generated GLB/glTF files and manifests are output artifacts and do not contain the add-on source code.

## Material height relief

For an authored finish, enable **Material Height Relief** in the advanced draft, then **Apply Draft**. Use **Assign Material** on roof covering, boarded enclosure, or exposed masonry. A compatible height source is discovered from the material and applied as editable Blender modifiers. Select the generated field and open **Advanced Tools** to see its height source or flat-fallback reason.

Use **Relief Subdivision** to change sampling density and **Relief Strength** to scale depth. Strength zero provides a flat mapped comparison. The material's **Height Image Override**, **Height Span (m)** and **Neutral Height** are optional persistent authoring controls. For Substance materials, enable or export the height channel from the same graph and preset as the visible channels. A matching sibling such as `stock_height.png` beside `stock_basecolor.png` resolves automatically. Non-Color, unit-range height data and shared UV mapping are required.

[Actual Substance material validation](evidence/assigned_relief/README.md)
