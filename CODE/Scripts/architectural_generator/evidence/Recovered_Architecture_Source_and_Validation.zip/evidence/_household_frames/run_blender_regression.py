import sys,unittest,time
from pathlib import Path
import bpy
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
names=('test_blender','test_roof_clearance','test_glass_timber_bvh','test_profiles_blender','test_world_blender')
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
r=unittest.TextTestRunner(verbosity=1).run(suite)
print('V05_BLENDER_REGRESSION',r.testsRun,'PASS' if r.wasSuccessful() else 'FAIL',flush=True)
if not r.wasSuccessful():raise SystemExit(1)
